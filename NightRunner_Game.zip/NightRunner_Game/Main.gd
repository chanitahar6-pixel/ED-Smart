extends Node3D

@onready var player: CharacterBody3D = $Player
@onready var camera: Camera3D = $CameraRig/Camera3D

func _ready() -> void:
	camera.current = true
	_update_camera(true)

func _process(delta: float) -> void:
	if is_instance_valid(player):
		_update_camera(false)

func _update_camera(snap: bool) -> void:
	var desired := player.global_position + Vector3(0.0, 3.6, 7.8)
	if snap:
		camera.global_position = desired
	else:
		camera.global_position = camera.global_position.lerp(desired, 1.0 - exp(-7.0 * get_process_delta_time()))
	camera.look_at(player.global_position + Vector3(0.0, 1.05, -4.5), Vector3.UP)
