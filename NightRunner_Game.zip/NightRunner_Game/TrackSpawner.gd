extends Node3D

# ── ثوابت ────────────────────────────────────────────────────────
const SEG_LEN       := 18.0
const AHEAD         := 12
const BEHIND        := 3
const LANE_X        := [-3.0, 0.0, 3.0]

# ── مشاهد ────────────────────────────────────────────────────────
const TrackScene    := preload("res://scenes/TrackSegment.tscn")
const TreeScene     := preload("res://scenes/Tree.tscn")
const PineScene     := preload("res://scenes/Pine.tscn")
const RockScene     := preload("res://scenes/Rock.tscn")
const BushScene     := preload("res://scenes/Bush.tscn")
const MountainScene := preload("res://scenes/Mountain.tscn")
const ObstacleScene := preload("res://ObstacleBlock.tscn")

# ── حالة ─────────────────────────────────────────────────────────
var _segs    : Array  = []
var _spawn_z : float  = 0.0
var _player  : Node3D = null
var _rng     := RandomNumberGenerator.new()

# ─────────────────────────────────────────────────────────────────
func _ready() -> void:
	_rng.randomize()
	await get_tree().process_frame
	_player = get_tree().get_first_node_in_group("player")
	# spawn جبال بعيدة مرة واحدة
	for i in range(4):
		var m = MountainScene.instantiate()
		m.position = Vector3((_rng.randf_range(-1.0, 1.0)) * 40.0, 0, -i * 60.0 - 60.0)
		add_child(m)
	# spawn مقاطع ابتدائية
	for _i in range(AHEAD):
		_spawn_segment()

func _process(_d: float) -> void:
	if not _player:
		return
	var pz := _player.position.z
	# spawn للأمام
	while _spawn_z > pz - AHEAD * SEG_LEN:
		_spawn_segment()
	# احذف خلف اللاعب
	while _segs.size() > 0:
		var s = _segs[0]
		if not is_instance_valid(s):
			_segs.pop_front(); continue
		if s.position.z > pz + BEHIND * SEG_LEN:
			s.queue_free(); _segs.pop_front()
		else:
			break

func _spawn_segment() -> void:
	var seg = TrackScene.instantiate()
	seg.position = Vector3(0, 0, _spawn_z)
	add_child(seg)
	_segs.append(seg)
	_spawn_env(_spawn_z)
	_spawn_obstacle(_spawn_z)
	_spawn_z -= SEG_LEN

func _spawn_env(z: float) -> void:
	# أشجار يسار
	if _rng.randf() < 0.75:
		var t = TreeScene.instantiate()
		t.position = Vector3(-7.0 - _rng.randf() * 4.0, 0, z + _rng.randf_range(-8, 8))
		add_child(t)
	# صنوبر يمين
	if _rng.randf() < 0.75:
		var p = PineScene.instantiate()
		p.position = Vector3(7.0 + _rng.randf() * 4.0, 0, z + _rng.randf_range(-8, 8))
		add_child(p)
	# صخور جانبية
	if _rng.randf() < 0.30:
		var r = RockScene.instantiate()
		var side := 1 if _rng.randf() < 0.5 else -1
		r.position = Vector3(side * (5.5 + _rng.randf() * 2.0), 0, z + _rng.randf_range(-7, 7))
		add_child(r)
	# شجيرات
	if _rng.randf() < 0.35:
		var b = BushScene.instantiate()
		var side := 1 if _rng.randf() < 0.5 else -1
		b.position = Vector3(side * (5.0 + _rng.randf() * 1.5), 0, z + _rng.randf_range(-7, 7))
		add_child(b)

func _spawn_obstacle(z: float) -> void:
	if z > -54.0:  # لا عقبات في أول 3 مقاطع
		return
	if _rng.randf() > 0.30:
		return
	var lane := _rng.randi_range(0, 2)
	var obs = ObstacleScene.instantiate()
	obs.position = Vector3(LANE_X[lane], 0, z + SEG_LEN * 0.5)
	add_child(obs)
