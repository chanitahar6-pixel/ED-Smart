extends CharacterBody3D

const LANES := [-3.0, 0.0, 3.0]
const BASE_SPEED := 12.0
const LANE_SPEED := 12.0
const GRAVITY := -28.0
const JUMP_FORCE := 10.0
const SLIDE_TIME := 0.72
const SWIPE_THRESHOLD := 45.0

var current_lane := 1
var target_x := 0.0
var is_sliding := false
var slide_timer := 0.0
var is_alive := true
var touch_start := Vector2.ZERO
var anim: AnimationPlayer
var gm: Node

@onready var col_normal: CollisionShape3D = $CollisionNormal
@onready var col_slide: CollisionShape3D = $CollisionSlide

func _ready() -> void:
	add_to_group("player")
	target_x = LANES[current_lane]
	gm = get_tree().get_first_node_in_group("game_manager")
	anim = find_child("AnimationPlayer", true, false)
	if anim:
		if anim.has_animation("Idle"):
			anim.play("Idle")
		await get_tree().create_timer(0.25).timeout
		if is_alive and anim and anim.has_animation("Run"):
			anim.play("Run")

func _physics_process(delta: float) -> void:
	if not is_alive:
		return

	var speed := BASE_SPEED
	if gm and gm.has_method("get_speed_multiplier"):
		speed *= gm.get_speed_multiplier()

	if not is_on_floor():
		velocity.y += GRAVITY * delta
	else:
		if velocity.y < 0.0:
			velocity.y = 0.0

	position.x = move_toward(position.x, target_x, LANE_SPEED * delta)
	velocity.z = -speed
	move_and_slide()

	if is_on_floor() and is_sliding:
		slide_timer -= delta
		if slide_timer <= 0.0:
			_end_slide()

func _input(event: InputEvent) -> void:
	if not is_alive:
		return
	if event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_A, KEY_LEFT: _lane_left()
			KEY_D, KEY_RIGHT: _lane_right()
			KEY_SPACE, KEY_W, KEY_UP: _try_jump()
			KEY_S, KEY_DOWN, KEY_CTRL: _try_slide()
	if event is InputEventScreenTouch:
		if event.pressed:
			touch_start = event.position
		else:
			_handle_swipe(event.position - touch_start)
	if event is InputEventScreenDrag:
		var diff := event.position - touch_start
		if diff.length() >= SWIPE_THRESHOLD:
			_handle_swipe(diff)
			touch_start = event.position

func _handle_swipe(diff: Vector2) -> void:
	if diff.length() < SWIPE_THRESHOLD:
		return
	if abs(diff.x) > abs(diff.y):
		if diff.x < 0.0:
			_lane_left()
		else:
			_lane_right()
	else:
		if diff.y < 0.0:
			_try_jump()
		else:
			_try_slide()

func _lane_left() -> void:
	if current_lane > 0:
		current_lane -= 1
		target_x = LANES[current_lane]

func _lane_right() -> void:
	if current_lane < 2:
		current_lane += 1
		target_x = LANES[current_lane]

func _try_jump() -> void:
	if is_on_floor() and not is_sliding:
		velocity.y = JUMP_FORCE
		if anim and anim.has_animation("Idle"):
			anim.play("Idle")

func _try_slide() -> void:
	if is_on_floor() and not is_sliding:
		_start_slide()

func _start_slide() -> void:
	is_sliding = true
	slide_timer = SLIDE_TIME
	col_normal.disabled = true
	col_slide.disabled = false
	if anim and anim.has_animation("Slide"):
		anim.play("Slide")

func _end_slide() -> void:
	is_sliding = false
	col_normal.disabled = false
	col_slide.disabled = true
	if anim and anim.has_animation("Run"):
		anim.play("Run")

func die() -> void:
	if not is_alive:
		return
	is_alive = false
	velocity = Vector3.ZERO
	if anim:
		anim.stop()
	if gm and gm.has_method("on_player_died"):
		gm.on_player_died()
