extends CharacterBody3D

# ── إعدادات ──────────────────────────────────────────────────────
const LANES         := [-3.0, 0.0, 3.0]
const LANE_SPEED    := 14.0
const BASE_SPEED    := 12.0
const GRAVITY       := -24.0
const JUMP_FORCE    := 10.0
const SLIDE_TIME    := 0.65
const SWIPE_THRESHOLD := 35.0

# ── حالة ─────────────────────────────────────────────────────────
var current_lane    : int   = 1
var target_x        : float = 0.0
var is_sliding      : bool  = false
var slide_timer     : float = 0.0
var is_alive        : bool  = true
var _touch_start    : Vector2 = Vector2.ZERO
var _anim           : AnimationPlayer = null
var _gm             : Node = null

@onready var col_normal : CollisionShape3D = $CollisionNormal
@onready var col_slide  : CollisionShape3D = $CollisionSlide

# ─────────────────────────────────────────────────────────────────
func _ready() -> void:
	add_to_group("player")
	target_x = LANES[current_lane]
	await get_tree().process_frame
	_gm   = get_tree().get_first_node_in_group("game_manager")
	_anim = find_child("AnimationPlayer", true, false)
	if _anim:
		_anim.play("Idle")
		await get_tree().create_timer(0.9).timeout
		if is_alive and _anim:
			_anim.play("Run")

func _physics_process(delta: float) -> void:
	if not is_alive:
		return
	var spd := BASE_SPEED * (_gm.get_speed_multiplier() if _gm else 1.0)

	# جاذبية
	if not is_on_floor():
		velocity.y += GRAVITY * delta
	elif velocity.y < 0:
		velocity.y = 0.0

	# حركة جانبية
	position.x = move_toward(position.x, target_x, LANE_SPEED * delta)

	# انزلاق
	if is_sliding:
		slide_timer -= delta
		if slide_timer <= 0.0:
			_end_slide()

	velocity.z = -spd
	move_and_slide()

# ── إدخال ────────────────────────────────────────────────────────
func _input(event: InputEvent) -> void:
	if not is_alive:
		return

	# كيبورد
	if event is InputEventKey and event.pressed:
		match event.keycode:
			KEY_A, KEY_LEFT:  _lane_left()
			KEY_D, KEY_RIGHT: _lane_right()
			KEY_SPACE, KEY_W, KEY_UP: _try_jump()
			KEY_S, KEY_DOWN, KEY_CTRL: _try_slide()

	# لمس — بداية
	if event is InputEventScreenTouch:
		if event.pressed:
			_touch_start = event.position

	# لمس — سحب
	if event is InputEventScreenDrag:
		var diff := event.position - _touch_start
		if diff.length() < SWIPE_THRESHOLD:
			return
		if abs(diff.x) > abs(diff.y):
			if diff.x < -SWIPE_THRESHOLD:
				_lane_left()
				_touch_start = event.position
			elif diff.x > SWIPE_THRESHOLD:
				_lane_right()
				_touch_start = event.position
		else:
			if diff.y < -SWIPE_THRESHOLD:
				_try_jump()
				_touch_start = event.position
			elif diff.y > SWIPE_THRESHOLD:
				_try_slide()
				_touch_start = event.position

# ── أوامر حركة ───────────────────────────────────────────────────
func _lane_left() -> void:
	if current_lane > 0:
		current_lane -= 1
		target_x = LANES[current_lane]

func _lane_right() -> void:
	if current_lane < 2:
		current_lane += 1
		target_x = LANES[current_lane]

func _try_jump() -> void:
	if is_on_floor() and not is_sliding:
		velocity.y = JUMP_FORCE

func _try_slide() -> void:
	if is_on_floor() and not is_sliding:
		_start_slide()

func _start_slide() -> void:
	is_sliding  = true
	slide_timer = SLIDE_TIME
	col_normal.disabled = true
	col_slide.disabled  = false
	if _anim:
		_anim.play("Slide")

func _end_slide() -> void:
	is_sliding = false
	col_normal.disabled = false
	col_slide.disabled  = true
	if _anim:
		_anim.play("Run")

# ── موت ──────────────────────────────────────────────────────────
func die() -> void:
	if not is_alive:
		return
	is_alive  = false
	velocity  = Vector3.ZERO
	if _anim:
		_anim.stop()
	if _gm:
		_gm.on_player_died()
