extends Node

signal score_updated(score: int)
signal game_over_signal

var score := 0
var distance := 0.0
var speed_multiplier := 1.0
var is_playing := false
var player: Node3D
var start_z := 0.0

func _ready() -> void:
	add_to_group("game_manager")
	await get_tree().process_frame
	player = get_tree().get_first_node_in_group("player")
	if player:
		start_z = player.position.z
	start_game()

func start_game() -> void:
	score = 0
	distance = 0.0
	speed_multiplier = 1.0
	is_playing = true

func _process(_delta: float) -> void:
	if not is_playing or not is_instance_valid(player):
		return
	distance = max(0.0, start_z - player.position.z)
	score = int(distance)
	speed_multiplier = min(1.0 + distance / 500.0, 2.5)
	score_updated.emit(score)

func get_speed_multiplier() -> float:
	return speed_multiplier

func on_player_died() -> void:
	if not is_playing:
		return
	is_playing = false
	game_over_signal.emit()
