extends Node

signal score_updated(score: int)
signal game_over_signal

var score: int = 0
var distance: float = 0.0
var speed_multiplier: float = 1.0
var is_playing: bool = false

func _ready() -> void:
	add_to_group("game_manager")
	await get_tree().process_frame
	start_game()

func start_game() -> void:
	score = 0
	distance = 0.0
	speed_multiplier = 1.0
	is_playing = true

func _process(delta: float) -> void:
	if not is_playing:
		return
	distance += delta * 12.0 * speed_multiplier
	score = int(distance)
	# تزيد الصعوبة كل 100m (max 2.5x)
	speed_multiplier = min(1.0 + distance / 500.0, 2.5)
	emit_signal("score_updated", score)

func get_speed_multiplier() -> float:
	return speed_multiplier

func on_player_died() -> void:
	if not is_playing:
		return
	is_playing = false
	emit_signal("game_over_signal")
