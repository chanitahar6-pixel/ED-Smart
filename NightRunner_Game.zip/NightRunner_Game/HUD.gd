extends CanvasLayer

@onready var score_label      : Label     = $ScoreLabel
@onready var game_over_panel  : ColorRect = $GameOverPanel
@onready var final_lbl        : Label     = $GameOverPanel/VBox/FinalScoreLabel
@onready var restart_btn      : Button    = $GameOverPanel/VBox/RestartButton
@onready var left_btn        : Button    = $TouchControls/Left
@onready var right_btn       : Button    = $TouchControls/Right
@onready var jump_btn        : Button    = $TouchControls/Jump
@onready var slide_btn       : Button    = $TouchControls/Slide

func _ready() -> void:
	game_over_panel.hide()
	await get_tree().process_frame
	var player = get_tree().get_first_node_in_group("player")
	if player:
		left_btn.pressed.connect(player._lane_left)
		right_btn.pressed.connect(player._lane_right)
		jump_btn.pressed.connect(player._try_jump)
		slide_btn.pressed.connect(player._try_slide)
	var gm = get_tree().get_first_node_in_group("game_manager")
	if gm:
		gm.score_updated.connect(_on_score)
		gm.game_over_signal.connect(_on_game_over)
	restart_btn.pressed.connect(_on_restart)

func _on_score(s: int) -> void:
	score_label.text = str(s) + "m"

func _on_game_over() -> void:
	game_over_panel.show()
	left_btn.disabled = true
	right_btn.disabled = true
	jump_btn.disabled = true
	slide_btn.disabled = true
	final_lbl.text = "المسافة: " + score_label.text

func _on_restart() -> void:
	get_tree().reload_current_scene()
