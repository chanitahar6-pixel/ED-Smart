# TV MOV — Android

تطبيق Android بواجهة مشاهدة مظلمة مستوحاة من تجربة تطبيقات البث الحديثة، مع أفلام ومسلسلات وأنمي، البحث، الفلاتر، التفاصيل، القوائم المحلية، والمشغل.

## Build compatibility

- Android Gradle Plugin: 9.1.1
- Gradle: 9.3.1
- JDK: 17
- compileSdk: 36
- targetSdk: 36
- minSdk: 24
- Compose BOM: 2026.04.01 (Compose 1.11 stable)
- AndroidX WebKit: 1.16.0 (requires minSdk 24)

## GitHub Actions

ضع `TVMOV_Android.zip` في جذر المستودع و`build-apk.yml` داخل `.github/workflows/`. الـworkflow يفك الضغط، يثبت Android API 36 وBuild Tools 36.0.0، ثم يبني `app-debug.apk`.

المصادر الخارجية للمحتوى يجب استخدامها فقط عندما تكون لديك حقوق أو إذن مناسب للوصول إليها وتوزيعها.
