# TV MOV — Android Streaming Catalog App

تطبيق Android أصلي بـ Kotlin + Jetpack Compose، مصمم كتجربة سينما حديثة مستوحاة من مبادئ تطبيقات البث الحديثة، وليس نسخة حرفية من Netflix.

## ما الذي تم بناؤه؟

- صفحة Home داكنة ومريحة مع Hero كبير.
- صفوف أفقية للمحتوى: متابعة المشاهدة، الأفلام، المسلسلات، الجديد، الترند، الأعلى تقييمًا، وأنمي/كرتون.
- شريط علوي فيه Hamburger + Search + Filter/Actions.
- شريط تنقل سفلي للوصول السريع إلى الرئيسية، الاستكشاف، البحث، قائمتي، والإعدادات.
- بحث فعلي عبر endpoint البحث الموجود في مشروع بوت Telegram.
- صفحة Explore مع فلاتر نوع المحتوى والسنة.
- صفحة تفاصيل حديثة: بوستر كبير، الاسم، السنة، التقييم، الوصف، المفضلة، وقائمة أرغب بمشاهدتها.
- المسلسلات: المواسم والحلقات مع جلب قائمة الحلقات من صفحات المصدر، مع fallback للحلقات 1–10 عندما لا يمكن استخراج القائمة.
- My List محلية على الجهاز: مفضلة، أرغب بمشاهدتها، وسجل المشاهدة.
- WebView Player مع 3 مصادر قابلة للتبديل كما كانت معرفة في مشروع البوت.
- حالات تحميل/خطأ/قوائم فارغة بدل انهيار التطبيق عند فشل المصدر.

## المصدر الذي تم ربطه

تمت مطابقة طبقة البيانات مع الكود الموجود في مشروع البوت `TV MOV.zip`:

- Base: `https://watchnest.org`
- Search: `GET /api/search?q=...`
- Movies: `/movies?page=N`
- TV: `/tv?page=N`
- New: `/new?page=N`
- Trending: `/trending?page=N`
- Top Rated: `/top-rated?page=N`
- Anime/Animation: يجرب عدة مسارات كما يفعل البوت ثم يختار مسارًا يعمل.
- Details: `/{movie|tv}/{id}` مع قراءة JSON-LD.
- TV episodes: `/watch/tv/{id}/{season}/1` مع عدة طرق لاستخراج أرقام الحلقات.

## مكان تعديل الـAPI

`app/src/main/java/com/blrx/tvmov/ApiConfig.kt`

طبقة الجلب كلها موجودة في:

`app/src/main/java/com/blrx/tvmov/MediaRepository.kt`

لذلك إذا تغيّر المصدر لاحقًا، لا تحتاج إلى إعادة بناء الواجهة؛ تعدّل Adapter/Repository فقط.

## المشاهدة

قوالب الـplayer موجودة في:

`app/src/main/java/com/blrx/tvmov/PlayerConfig.kt`

استخدم مصادر المشاهدة فقط للمحتوى الذي تملك حق الوصول إليه أو توزيعه.

## البناء

المشروع يستخدم:

- Android Gradle Plugin 9.1.1
- Gradle 9.3.1
- JDK 17
- Kotlin 2.2.20
- Jetpack Compose BOM 2026.08.00

هذه الإصدارات تم اختيارها بعد مراجعة جداول التوافق الرسمية الحالية.

## GitHub Actions

الملف الخارجي `build-apk.yml` يفترض أنك وضعت `TVMOV_Android.zip` في جذر repository مع ملف workflow في:

`.github/workflows/build-apk.yml`

الـworkflow يفعل التالي:

1. checkout.
2. فك ضغط المشروع من ZIP.
3. إعداد JDK 17.
4. تنزيل/إعداد Gradle 9.3.1.
5. تشغيل `:app:assembleDebug`.
6. رفع `TVMOV-debug.apk` كـartifact.

لا يحتاج المشروع إلى Gradle Wrapper، لذلك الـworkflow نفسه هو الذي يجهز Gradle ويشغله.


### إصلاح Gradle / AGP 9.1.1

تم تحديث المشروع ليتوافق مع AGP 9.1.1 وKotlin المدمج في AGP 9.x:
- إزالة `org.jetbrains.kotlin.android` من root وapp.
- استخدام Compose Compiler plugin `2.3.21`.
- تثبيت Java toolchain على JDK 17.

هذا يعالج خطأ `The 'org.jetbrains.kotlin.android' plugin is no longer required for Kotlin support since AGP 9.0`.
