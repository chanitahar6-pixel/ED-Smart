# TVMOV keeps the release build straightforward; the app is not minified by default.
