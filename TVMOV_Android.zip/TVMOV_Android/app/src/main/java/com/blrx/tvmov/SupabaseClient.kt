package com.blrx.tvmov

import android.content.Context
import android.net.Uri
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Lightweight REST client. It deliberately uses the existing OkHttp dependency so build versions stay unchanged. */
class SupabaseClient(context: Context) {
    private val prefs = context.getSharedPreferences("tvmov_supabase", Context.MODE_PRIVATE)
    private val http = OkHttpClient.Builder().build()

    data class Session(val accessToken: String, val refreshToken: String, val userId: String?, val email: String?)
    data class Profile(val username: String, val avatarUrl: String?, val coverUrl: String?)

    fun hasSession(): Boolean = prefs.getString(KEY_ACCESS, null).orEmpty().isNotBlank()
    fun userId(): String? = prefs.getString(KEY_USER_ID, null)
    fun accessToken(): String? = prefs.getString(KEY_ACCESS, null)
    fun email(): String? = prefs.getString(KEY_EMAIL, null)

    fun signUp(email: String, password: String, username: String): Result<Boolean> = runCatching {
        val body = JSONObject().apply {
            put("email", email.trim())
            put("password", password)
            put("data", JSONObject().put("full_name", username.trim().ifBlank { "مستخدم TV MOV" }))
            put("email_redirect_to", REDIRECT_URI)
        }
        val response = request("/auth/v1/signup", "POST", body.toString(), null)
        if (response.code !in 200..299) error(apiError(response.body, "تعذر إنشاء الحساب"))
        val json = response.body?.let(::JSONObject) ?: JSONObject()
        val access = json.optString("access_token")
        val refresh = json.optString("refresh_token")
        if (access.isNotBlank() && refresh.isNotBlank()) saveSession(access, refresh, json.optJSONObject("user"))
        true
    }

    fun signIn(email: String, password: String): Result<Boolean> = runCatching {
        val response = request("/auth/v1/token?grant_type=password", "POST", JSONObject().apply {
            put("email", email.trim())
            put("password", password)
        }.toString(), null)
        if (response.code !in 200..299) error(apiError(response.body, "البريد الإلكتروني أو كلمة المرور غير صحيحة"))
        val json = JSONObject(response.body ?: "{}")
        saveSession(json.optString("access_token"), json.optString("refresh_token"), json.optJSONObject("user"))
        true
    }

    fun recover(email: String): Result<Boolean> = runCatching {
        val response = request("/auth/v1/recover", "POST", JSONObject().apply {
            put("email", email.trim())
            put("redirect_to", REDIRECT_URI)
        }.toString(), null)
        if (response.code !in 200..299) error(apiError(response.body, "تعذر إرسال رسالة الاستعادة"))
        true
    }

    fun updatePassword(newPassword: String): Result<Boolean> = runCatching {
        val response = request("/auth/v1/user", "PUT", JSONObject().put("password", newPassword).toString(), accessToken())
        if (response.code !in 200..299) error(apiError(response.body, "تعذر تغيير كلمة المرور"))
        true
    }

    fun refreshSession(): Boolean {
        val refresh = prefs.getString(KEY_REFRESH, null).orEmpty()
        if (refresh.isBlank()) return false
        val response = request("/auth/v1/token?grant_type=refresh_token", "POST", JSONObject().put("refresh_token", refresh).toString(), null)
        if (response.code !in 200..299) return false
        return runCatching {
            val json = JSONObject(response.body ?: "{}")
            saveSession(json.optString("access_token"), json.optString("refresh_token", refresh), json.optJSONObject("user"))
            true
        }.getOrDefault(false)
    }

    fun acceptDeepLinkSession(access: String, refresh: String) {
        val parts = access.split(".")
        val user = if (parts.size >= 2) runCatching { JSONObject(String(android.util.Base64.decode(parts[1], android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP))) }.getOrNull() else null
        saveSession(access, refresh, user?.let { JSONObject().apply { put("id", it.optString("sub")); put("email", it.optString("email")) } })
    }

    fun signOut() {
        val token = accessToken()
        if (!token.isNullOrBlank()) request("/auth/v1/logout", "POST", null, token)
        prefs.edit().clear().apply()
    }

    fun getProfile(): Result<Profile> = runCatching {
        val id = userId() ?: error("لا يوجد حساب مسجل")
        val response = request("/rest/v1/profiles?id=eq.$id&select=username,avatar_url,cover_url&limit=1", "GET", null, accessToken())
        if (response.code !in 200..299) error(apiError(response.body, "تعذر تحميل الملف الشخصي"))
        val arr = JSONArray(response.body ?: "[]")
        if (arr.length() == 0) {
            Profile("مستخدم TV MOV", null, null)
        } else {
            val o = arr.getJSONObject(0)
            Profile(o.optString("username", "مستخدم TV MOV"), o.optString("avatar_url").ifBlank { null }, o.optString("cover_url").ifBlank { null })
        }
    }

    fun updateProfile(username: String, avatarUrl: String?, coverUrl: String?): Result<Boolean> = runCatching {
        val id = userId() ?: error("لا يوجد حساب مسجل")
        val body = JSONObject().apply {
            put("id", id)
            put("username", username.trim().ifBlank { "مستخدم TV MOV" })
            if (avatarUrl == null) put("avatar_url", JSONObject.NULL) else put("avatar_url", avatarUrl)
            if (coverUrl == null) put("cover_url", JSONObject.NULL) else put("cover_url", coverUrl)
        }
        val response = request("/rest/v1/profiles?id=eq.$id", "PATCH", body.toString(), accessToken(), mapOf("Prefer" to "return=minimal"))
        if (response.code !in 200..299) error(apiError(response.body, "تعذر حفظ الملف الشخصي"))
        true
    }

    fun uploadProfileImage(bytes: ByteArray, mime: String, extension: String): Result<String> = runCatching {
        val id = userId() ?: error("لا يوجد حساب مسجل")
        val safeExt = extension.lowercase().replace(Regex("[^a-z0-9]"), "").ifBlank { "jpg" }
        val path = "$id/${UUID.randomUUID()}.$safeExt"
        val response = requestBytes("/storage/v1/object/profile-media/$path", "POST", bytes, mime, accessToken(), mapOf("x-upsert" to "true"))
        if (response.code !in 200..299) error(apiError(response.body, "تعذر رفع الصورة"))
        "${ApiConfig.SUPABASE_URL}/storage/v1/object/public/profile-media/$path"
    }

    fun upsertLibrary(item: MediaItem, listType: String): Boolean {
        val uid = userId() ?: return false
        val mediaType = when {
            item.mediaType == "movie" -> "movie"
            item.mediaType == "tv" -> "tv"
            item.sourceCategory?.contains("anime", true) == true -> "anime"
            else -> item.mediaType.ifBlank { "other" }
        }
        val body = JSONObject().apply {
            put("user_id", uid); put("list_type", listType); put("media_key", item.key)
            put("media_id", item.id); put("media_type", mediaType); put("title", item.title)
            put("poster", item.poster ?: JSONObject.NULL); put("year", item.year)
            if (item.rating != null) put("rating", item.rating) else put("rating", JSONObject.NULL)
            put("overview", item.overview); if (item.seasons != null) put("seasons", item.seasons) else put("seasons", JSONObject.NULL)
            put("source_category", item.sourceCategory ?: JSONObject.NULL)
        }
        val response = request("/rest/v1/user_library?on_conflict=user_id,list_type,media_key", "POST", body.toString(), accessToken(), mapOf("Prefer" to "resolution=merge-duplicates,return=minimal"))
        return response.code in 200..299
    }

    fun deleteLibrary(item: MediaItem, listType: String): Boolean {
        val uid = userId() ?: return false
        val response = request("/rest/v1/user_library?user_id=eq.$uid&list_type=eq.$listType&media_key=eq.${Uri.encode(item.key)}", "DELETE", null, accessToken(), mapOf("Prefer" to "return=minimal"))
        return response.code in 200..299
    }

    fun loadLibrary(listType: String): List<MediaItem> {
        val uid = userId() ?: return emptyList()
        val response = request("/rest/v1/user_library?user_id=eq.$uid&list_type=eq.$listType&select=*&order=updated_at.desc", "GET", null, accessToken())
        if (response.code !in 200..299) return emptyList()
        val arr = JSONArray(response.body ?: "[]")
        return buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(MediaItem(o.optInt("media_id"), o.optString("media_type"), o.optString("title"), o.optString("poster").ifBlank { null }, o.optString("year"), if (o.isNull("rating")) null else o.optDouble("rating"), o.optString("overview"), if (o.isNull("seasons")) null else o.optInt("seasons"), o.optString("source_category").ifBlank { null }))
            }
        }
    }

    private fun saveSession(access: String, refresh: String, user: JSONObject?) {
        if (access.isBlank()) error("لم تصل جلسة صالحة من Supabase")
        prefs.edit()
            .putString(KEY_ACCESS, access)
            .putString(KEY_REFRESH, refresh)
            .putString(KEY_USER_ID, user?.optString("id").orEmpty())
            .putString(KEY_EMAIL, user?.optString("email").orEmpty())
            .apply()
    }

    private data class Response(val code: Int, val body: String?)

    private fun request(path: String, method: String, body: String?, token: String?, extra: Map<String, String> = emptyMap()): Response {
        val builder = Request.Builder().url(ApiConfig.SUPABASE_URL + path)
            .header("apikey", ApiConfig.SUPABASE_PUBLISHABLE_KEY)
            .header("Accept", "application/json")
        if (!token.isNullOrBlank()) builder.header("Authorization", "Bearer $token")
        extra.forEach { (k, v) -> builder.header(k, v) }
        val requestBody = body?.toRequestBody("application/json; charset=utf-8".toMediaType())
        when (method) { "POST" -> builder.post(requestBody ?: "".toRequestBody()); "PATCH" -> builder.patch(requestBody ?: "".toRequestBody()); "PUT" -> builder.put(requestBody ?: "".toRequestBody()); "DELETE" -> builder.delete(requestBody); else -> builder.get() }
        return http.newCall(builder.build()).execute().use { Response(it.code, it.body?.string()) }
    }

    private fun requestBytes(path: String, method: String, bytes: ByteArray, mime: String, token: String?, extra: Map<String, String> = emptyMap()): Response {
        val builder = Request.Builder().url(ApiConfig.SUPABASE_URL + path).header("apikey", ApiConfig.SUPABASE_PUBLISHABLE_KEY).header("Content-Type", mime)
        if (!token.isNullOrBlank()) builder.header("Authorization", "Bearer $token")
        extra.forEach { (k, v) -> builder.header(k, v) }
        builder.post(bytes.toRequestBody(mime.toMediaType()))
        return http.newCall(builder.build()).execute().use { Response(it.code, it.body?.string()) }
    }

    private fun apiError(body: String?, fallback: String): String = runCatching {
        val o = JSONObject(body ?: "{}"); o.optString("message").ifBlank { o.optString("msg").ifBlank { fallback } }
    }.getOrDefault(fallback)

    companion object {
        const val REDIRECT_URI = "tvmov://auth/callback"
        private const val KEY_ACCESS = "access_token"
        private const val KEY_REFRESH = "refresh_token"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_EMAIL = "email"
    }
}
