package com.blrx.tvmov

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = MediaRepository()
    private val store = LocalStore(application)

    private val _catalog = MutableStateFlow(CatalogState())
    val catalog: StateFlow<CatalogState> = _catalog.asStateFlow()

    private val _search = MutableStateFlow<List<MediaItem>>(emptyList())
    val search: StateFlow<List<MediaItem>> = _search.asStateFlow()

    private val _details = MutableStateFlow<MediaItem?>(null)
    val details: StateFlow<MediaItem?> = _details.asStateFlow()

    private val _detailExtras = MutableStateFlow(DetailExtras())
    val detailExtras: StateFlow<DetailExtras> = _detailExtras.asStateFlow()

    private val _episodes = MutableStateFlow<List<Int>>(emptyList())
    val episodes: StateFlow<List<Int>> = _episodes.asStateFlow()

    private val _favorites = MutableStateFlow(store.getFavorites())
    val favorites: StateFlow<List<MediaItem>> = _favorites.asStateFlow()

    private val _watchLater = MutableStateFlow(store.getWatchLater())
    val watchLater: StateFlow<List<MediaItem>> = _watchLater.asStateFlow()

    private val _history = MutableStateFlow(store.getHistory())
    val history: StateFlow<List<MediaItem>> = _history.asStateFlow()

    fun loadHome(force: Boolean = false) {
        if (!force && _catalog.value.sections.isNotEmpty()) return
        viewModelScope.launch {
            _catalog.value = _catalog.value.copy(loading = true, error = null)
            runCatching {
                HomeSection.values().map { section -> async { section to repo.catalog(section) } }.awaitAll().toMap()
            }.onSuccess { sections ->
                _catalog.value = CatalogState(sections = sections, loading = false)
            }.onFailure { e ->
                _catalog.value = CatalogState(loading = false, error = e.message ?: "تعذر تحميل المحتوى")
            }
        }
    }

    fun search(query: String) {
        if (query.isBlank()) {
            _search.value = emptyList()
            return
        }
        viewModelScope.launch {
            _search.value = repo.search(query)
        }
    }

    fun open(item: MediaItem) {
        _details.value = item
        _detailExtras.value = DetailExtras()
        viewModelScope.launch {
            val detailJob = async { repo.details(item) }
            val extrasJob = async { repo.detailExtras(item) }
            val full = detailJob.await()
            _details.value = full
            _detailExtras.value = extrasJob.await()
            store.addHistory(full)
            _history.value = store.getHistory()
        }
    }

    fun loadEpisodes(item: MediaItem, season: Int) {
        viewModelScope.launch {
            _episodes.value = repo.episodes(item, season)
        }
    }

    suspend fun resolveDirectPlayer(source: PlayerSource): PlayerSource {
        val direct = runCatching { repo.resolveDirectStream(source.url) }.getOrNull()
        return if (direct.isNullOrBlank()) source else source.copy(url = direct, direct = true)
    }

    fun toggleFavorite(item: MediaItem) {
        store.toggleFavorite(item)
        _favorites.value = store.getFavorites()
    }

    fun toggleWatchLater(item: MediaItem) {
        store.toggleWatchLater(item)
        _watchLater.value = store.getWatchLater()
    }

    fun clearHistory() {
        store.clearHistory()
        _history.value = emptyList()
    }

    fun clearFavorites() {
        store.clearFavorites()
        _favorites.value = emptyList()
    }

    fun clearWatchLater() {
        store.clearWatchLater()
        _watchLater.value = emptyList()
    }
}
