package com.blrx.tvmov

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = MediaRepository()
    private val store = LocalStore(application)
    private val supabase = SupabaseClient(application)

    private val _catalog = MutableStateFlow(CatalogState())
    val catalog: StateFlow<CatalogState> = _catalog.asStateFlow()
    private val _search = MutableStateFlow<List<MediaItem>>(emptyList())
    val search: StateFlow<List<MediaItem>> = _search.asStateFlow()
    private val _details = MutableStateFlow<MediaItem?>(null)
    val details: StateFlow<MediaItem?> = _details.asStateFlow()
    private val _detailExtras = MutableStateFlow(DetailExtras())
    val detailExtras: StateFlow<DetailExtras> = _detailExtras.asStateFlow()
    private val _episodes = MutableStateFlow<List<Int>>(emptyList())
    val episodes: StateFlow<List<Int>> = _episodes.asStateFlow()
    private val _favorites = MutableStateFlow(store.getFavorites())
    val favorites: StateFlow<List<MediaItem>> = _favorites.asStateFlow()
    private val _watchLater = MutableStateFlow(store.getWatchLater())
    val watchLater: StateFlow<List<MediaItem>> = _watchLater.asStateFlow()
    private val _history = MutableStateFlow(store.getHistory())
    val history: StateFlow<List<MediaItem>> = _history.asStateFlow()

    private val _loggedIn = MutableStateFlow(supabase.hasSession())
    val loggedIn: StateFlow<Boolean> = _loggedIn.asStateFlow()
    private val _profile = MutableStateFlow<SupabaseClient.Profile?>(null)
    val profile: StateFlow<SupabaseClient.Profile?> = _profile.asStateFlow()
    private val _authBusy = MutableStateFlow(false)
    val authBusy: StateFlow<Boolean> = _authBusy.asStateFlow()
    private val _authMessage = MutableStateFlow<String?>(null)
    val authMessage: StateFlow<String?> = _authMessage.asStateFlow()

    init {
        if (supabase.hasSession()) loadCloudData()
    }

    fun clearAuthMessage() { _authMessage.value = null }

    fun loadHome(force: Boolean = false) {
        if (!force && _catalog.value.sections.isNotEmpty()) return
        viewModelScope.launch {
            _catalog.value = _catalog.value.copy(loading = true, error = null)
            runCatching {
                HomeSection.values().map { section -> async { section to repo.catalog(section) } }.awaitAll().toMap()
            }.onSuccess { sections -> _catalog.value = CatalogState(sections = sections, loading = false) }
                .onFailure { e -> _catalog.value = CatalogState(loading = false, error = e.message ?: "تعذر تحميل المحتوى") }
        }
    }

    fun search(query: String) {
        if (query.isBlank()) { _search.value = emptyList(); return }
        viewModelScope.launch { _search.value = repo.search(query) }
    }

    fun open(item: MediaItem) {
        _details.value = item; _detailExtras.value = DetailExtras()
        viewModelScope.launch {
            val detailJob = async { repo.details(item) }
            val extrasJob = async { repo.detailExtras(item) }
            val full = detailJob.await()
            _details.value = full; _detailExtras.value = extrasJob.await()
            store.addHistory(full); _history.value = store.getHistory()
            if (supabase.hasSession()) syncItem(full, "history")
        }
    }

    fun loadEpisodes(item: MediaItem, season: Int) { viewModelScope.launch { _episodes.value = repo.episodes(item, season) } }
    suspend fun resolveDirectPlayer(source: PlayerSource): PlayerSource {
        val direct = runCatching { repo.resolveDirectStream(source.url) }.getOrNull()
        return if (direct.isNullOrBlank()) source else source.copy(url = direct, direct = true)
    }

    fun toggleFavorite(item: MediaItem) {
        val added = store.toggleFavorite(item); _favorites.value = store.getFavorites()
        if (supabase.hasSession()) viewModelScope.launch(Dispatchers.IO) { if (added) supabase.upsertLibrary(item, "favorite") else supabase.deleteLibrary(item, "favorite") }
    }

    fun toggleWatchLater(item: MediaItem) {
        val added = store.toggleWatchLater(item); _watchLater.value = store.getWatchLater()
        if (supabase.hasSession()) viewModelScope.launch(Dispatchers.IO) { if (added) supabase.upsertLibrary(item, "watch_later") else supabase.deleteLibrary(item, "watch_later") }
    }

    fun clearHistory() { val old = _history.value; store.clearHistory(); _history.value = emptyList(); if (supabase.hasSession()) clearCloudList("history", old) }
    fun clearFavorites() { val old = _favorites.value; store.clearFavorites(); _favorites.value = emptyList(); if (supabase.hasSession()) clearCloudList("favorite", old) }
    fun clearWatchLater() { val old = _watchLater.value; store.clearWatchLater(); _watchLater.value = emptyList(); if (supabase.hasSession()) clearCloudList("watch_later", old) }

    fun signUp(email: String, password: String, username: String) = authAction {
        val result = withContext(Dispatchers.IO) { supabase.signUp(email, password, username) }
        if (result.isFailure) error(result.exceptionOrNull()?.message ?: "تعذر إنشاء الحساب")
        if (supabase.hasSession()) finishLogin()
        else _authMessage.value = "تم إنشاء الحساب. تحقق من بريدك الإلكتروني ثم سجّل الدخول."
    }

    fun signIn(email: String, password: String) = authAction {
        val result = withContext(Dispatchers.IO) { supabase.signIn(email, password) }
        if (result.isFailure) error(result.exceptionOrNull()?.message ?: "تعذر تسجيل الدخول")
        finishLogin()
    }

    fun recover(email: String) = authAction {
        val result = withContext(Dispatchers.IO) { supabase.recover(email) }
        if (result.isFailure) error(result.exceptionOrNull()?.message ?: "تعذر إرسال رسالة الاستعادة")
        _authMessage.value = "إذا كان البريد مرتبطًا بحساب، ستصلك رسالة استعادة كلمة المرور."
    }

    fun updatePassword(password: String) = authAction {
        val result = withContext(Dispatchers.IO) { supabase.updatePassword(password) }
        if (result.isFailure) error(result.exceptionOrNull()?.message ?: "تعذر تغيير كلمة المرور")
        _authMessage.value = "تم تغيير كلمة المرور بنجاح."
    }

    fun signOut() {
        viewModelScope.launch(Dispatchers.IO) {
            supabase.signOut()
            _loggedIn.value = false; _profile.value = null
        }
    }

    fun loadProfile() {
        if (!supabase.hasSession()) return
        viewModelScope.launch(Dispatchers.IO) { _profile.value = supabase.getProfile().getOrNull() }
    }

    fun updateProfile(username: String, avatarUrl: String?, coverUrl: String?) = authAction {
        val result = withContext(Dispatchers.IO) { supabase.updateProfile(username, avatarUrl, coverUrl) }
        if (result.isFailure) error(result.exceptionOrNull()?.message ?: "تعذر حفظ الملف الشخصي")
        loadProfile()
    }

    suspend fun uploadProfileImage(bytes: ByteArray, mime: String, extension: String): Result<String> = withContext(Dispatchers.IO) { supabase.uploadProfileImage(bytes, mime, extension) }

    fun handleAuthDeepLink(uri: android.net.Uri?): Boolean {
        if (uri == null || uri.scheme != "tvmov" || uri.host != "auth") return false
        val fragment = uri.fragment ?: return false
        val values = fragment.split('&').mapNotNull { part ->
            val p = part.split('=', limit = 2); if (p.size == 2) p[0] to android.net.Uri.decode(p[1]) else null
        }.toMap()
        val access = values["access_token"] ?: return false
        val refresh = values["refresh_token"] ?: return false
        val type = values["type"]
        viewModelScope.launch(Dispatchers.IO) {
            supabase.acceptDeepLinkSession(access, refresh)
            _loggedIn.value = true
            loadCloudData()
            loadProfile()
        }
        return type == "recovery"
    }

    fun localListFor(listType: String): List<MediaItem> = when (listType) { "favorite" -> _favorites.value; "watch_later" -> _watchLater.value; else -> _history.value }

    private fun finishLogin() {
        _loggedIn.value = true
        loadCloudData()
        loadProfile()
        _authMessage.value = "تم تسجيل الدخول بنجاح."
    }

    private fun loadCloudData() {
        viewModelScope.launch(Dispatchers.IO) {
            val cloudFavorites = supabase.loadLibrary("favorite")
            val cloudWatchLater = supabase.loadLibrary("watch_later")
            val cloudHistory = supabase.loadLibrary("history")
            val mergedFav = merge(store.getFavorites(), cloudFavorites)
            val mergedLater = merge(store.getWatchLater(), cloudWatchLater)
            val mergedHistory = merge(store.getHistory(), cloudHistory)
            store.replaceFavorites(mergedFav); store.replaceWatchLater(mergedLater); store.replaceHistory(mergedHistory)
            _favorites.value = mergedFav; _watchLater.value = mergedLater; _history.value = mergedHistory
            mergedFav.forEach { supabase.upsertLibrary(it, "favorite") }
            mergedLater.forEach { supabase.upsertLibrary(it, "watch_later") }
            mergedHistory.forEach { supabase.upsertLibrary(it, "history") }
        }
    }

    private fun merge(local: List<MediaItem>, cloud: List<MediaItem>): List<MediaItem> {
        val map = LinkedHashMap<String, MediaItem>()
        (cloud + local).forEach { map.putIfAbsent(it.key, it) }
        return map.values.toList()
    }

    private fun syncItem(item: MediaItem, type: String) { viewModelScope.launch(Dispatchers.IO) { supabase.upsertLibrary(item, type) } }
    private fun clearCloudList(type: String, items: List<MediaItem>) {
        viewModelScope.launch(Dispatchers.IO) { items.forEach { supabase.deleteLibrary(it, type) } }
    }

    private fun authAction(block: suspend () -> Unit) {
        viewModelScope.launch {
            _authBusy.value = true; _authMessage.value = null
            try { block() } catch (e: Exception) { _authMessage.value = e.message ?: "حدث خطأ" }
            finally { _authBusy.value = false }
        }
    }
}
