package com.blrx.tvmov

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Background = Color(0xFF080A0F)
private val Surface = Color(0xFF11151D)
private val Surface2 = Color(0xFF171C25)
private val Text = Color(0xFFF4F5F7)
private val Muted = Color(0xFF9DA5B2)
private val Accent = Color(0xFFE50914)

@Composable
fun TVMOVTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            onPrimary = Color.White,
            background = Background,
            onBackground = Text,
            surface = Surface,
            onSurface = Text,
            surfaceVariant = Surface2,
            onSurfaceVariant = Muted,
            secondary = Accent
        ),
        content = content
    )
}
