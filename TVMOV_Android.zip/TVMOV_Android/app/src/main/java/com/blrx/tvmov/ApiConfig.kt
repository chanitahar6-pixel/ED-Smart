package com.blrx.tvmov

object ApiConfig {
    const val BASE_URL = "https://watchnest.org"
    const val SEARCH_PATH = "/api/search"

    // Supabase project used by TV MOV.
    const val SUPABASE_URL = "https://zosqvajletgvzqvxgzgu.supabase.co"
    const val SUPABASE_PUBLISHABLE_KEY = "sb_publishable_e5ERKoefOweLQSoxxWlZ8g_N7OjNMrv"

    const val USER_AGENT =
        "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36"

    val headers: Map<String, String> = mapOf(
        "User-Agent" to USER_AGENT,
        "Accept" to "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8"
    )
}
