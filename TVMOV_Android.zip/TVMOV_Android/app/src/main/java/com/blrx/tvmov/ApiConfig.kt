package com.blrx.tvmov

object ApiConfig {
    const val BASE_URL = "https://watchnest.org"
    const val SEARCH_PATH = "/api/search"

    const val USER_AGENT =
        "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36"

    val headers: Map<String, String> = mapOf(
        "User-Agent" to USER_AGENT,
        "Accept" to "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8"
    )
}
