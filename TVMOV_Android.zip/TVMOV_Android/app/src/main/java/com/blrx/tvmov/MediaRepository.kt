package com.blrx.tvmov

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import org.jsoup.Jsoup
import java.net.URLDecoder
import java.util.Locale
import java.util.concurrent.TimeUnit

class MediaRepository {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .callTimeout(30, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    suspend fun catalog(section: HomeSection, page: Int = 1): List<MediaItem> = withContext(Dispatchers.IO) {
        val url = when (section) {
            HomeSection.Anime -> findAnimeUrl(page)
            else -> "${ApiConfig.BASE_URL}/${section.path}?page=$page"
        } ?: return@withContext emptyList()
        parseCards(get(url), section.label)
    }

    suspend fun search(query: String): List<MediaItem> = withContext(Dispatchers.IO) {
        val httpUrl = ApiConfig.BASE_URL.toHttpUrl().newBuilder()
            .addPathSegments(ApiConfig.SEARCH_PATH.removePrefix("/"))
            .addQueryParameter("q", query.trim())
            .build()
        val body = get(httpUrl.toString())
        runCatching {
            val root = JSONObject(body)
            val results = root.optJSONArray("results") ?: return@runCatching emptyList()
            buildList {
                for (i in 0 until results.length()) {
                    val o = results.optJSONObject(i) ?: continue
                    val type = o.optString("media_type")
                    if (type != "movie" && type != "tv") continue
                    add(
                        MediaItem(
                            id = o.optInt("id"),
                            mediaType = type,
                            title = o.optString("title").ifBlank { o.optString("name") },
                            poster = normalizeImage(o.optString("poster_path")),
                            year = o.optString("release_date").take(4).ifBlank { o.optString("first_air_date").take(4) }
                        )
                    )
                }
            }.take(30)
        }.getOrElse { emptyList() }
    }

    suspend fun details(item: MediaItem): MediaItem = withContext(Dispatchers.IO) {
        parseDetailsHtml(runCatching { get("${ApiConfig.BASE_URL}/${item.mediaType}/${item.id}") }.getOrNull(), item).first
    }

    suspend fun detailExtras(item: MediaItem): DetailExtras = withContext(Dispatchers.IO) {
        val html = runCatching { get("${ApiConfig.BASE_URL}/${item.mediaType}/${item.id}") }.getOrNull()
            ?: return@withContext DetailExtras()
        parseDetailsHtml(html, item).second
    }

    suspend fun episodes(item: MediaItem, season: Int): List<Int> = withContext(Dispatchers.IO) {
        val url = "${ApiConfig.BASE_URL}/watch/tv/${item.id}/$season/1"
        val html = runCatching { get(url) }.getOrNull() ?: return@withContext fallbackEpisodes()
        val found = linkedSetOf<Int>()
        Regex("/watch/tv/${item.id}/$season/(\\d+)").findAll(html).forEach { found += it.groupValues[1].toIntOrNull() ?: 0 }
        Regex("data-ep(?:isode)?=[\\\"'](\\d+)[\\\"']").findAll(html).forEach { found += it.groupValues[1].toIntOrNull() ?: 0 }
        Regex("[\\\"']episode[\\\"']\\s*:\\s*(\\d+)").findAll(html).forEach { found += it.groupValues[1].toIntOrNull() ?: 0 }
        found.filter { it in 1..5000 }.sorted().ifEmpty { fallbackEpisodes() }
    }

    suspend fun resolveDirectStream(embedUrl: String): String? = withContext(Dispatchers.IO) {
        val html = runCatching { get(embedUrl) }.getOrNull() ?: return@withContext null
        val candidates = linkedSetOf<String>()
        val patterns = listOf(
            Regex("https?://[^\\\"'<>\\s]+\\.m3u8(?:\\?[^\\\"'<>\\s]+)?", RegexOption.IGNORE_CASE),
            Regex("https?://[^\\\"'<>\\s]+\\.mp4(?:\\?[^\\\"'<>\\s]+)?", RegexOption.IGNORE_CASE),
            Regex("(?:src|file|source|url)\\s*[:=]\\s*[\\\"']([^\\\"']+\\.(?:m3u8|mp4)(?:\\?[^\\\"']*)?)[\\\"']", RegexOption.IGNORE_CASE)
        )
        patterns.forEach { regex ->
            regex.findAll(html).forEach { match ->
                val raw = match.groupValues.lastOrNull().orEmpty()
                val decoded = runCatching { URLDecoder.decode(raw, "UTF-8") }.getOrDefault(raw)
                if (decoded.startsWith("http")) candidates += decoded
            }
        }
        candidates.firstOrNull { looksLikeDirectStream(it) }
    }

    private fun parseDetailsHtml(html: String?, item: MediaItem): Pair<MediaItem, DetailExtras> {
        if (html.isNullOrBlank()) return item to DetailExtras()
        var best: JSONObject? = null
        val cast = LinkedHashMap<String, CastMember>()
        val scripts = Regex("<script[^>]*type=[\\\"']application/ld\\+json[\\\"'][^>]*>([\\s\\S]*?)</script>", RegexOption.IGNORE_CASE)
        for (script in scripts.findAll(html)) {
            val raw = script.groupValues.getOrNull(1)?.trim().orEmpty()
            if (raw.isBlank()) continue
            val parsed = parseJsonObjectOrArray(raw) ?: continue
            val objects = when (parsed) {
                is JSONObject -> sequenceOf(parsed) + parsed.optJSONArray("@graph").asSequenceSafe()
                is JSONArray -> (0 until parsed.length()).asSequence().mapNotNull { parsed.optJSONObject(it) }
                else -> emptySequence()
            }
            objects.forEach { obj ->
                if (looksLikeMedia(obj)) best = obj
                addActorJson(obj.opt("actor"), cast)
                addActorJson(obj.opt("actors"), cast)
            }
        }

        val doc = Jsoup.parse(html)
        doc.select("a[href^=/movie/], a[href^=/tv/]").forEach { a ->
            val href = a.attr("href")
            val match = Regex("^/(movie|tv)/(\\d+)").find(href) ?: return@forEach
            val id = match.groupValues[2].toIntOrNull() ?: return@forEach
            if (id == item.id) return@forEach
            val img = a.selectFirst("img")
            val title = img?.attr("alt").orEmpty().ifBlank { a.text() }.replace(Regex("\\s+"), " ").trim()
            if (title.isBlank() || title.length < 2) return@forEach
            val parentText = a.parents().take(5).joinToString(" ") { it.text() }.lowercase(Locale.ROOT)
            val similarHint = listOf("similar", "recommended", "recommend", "you may also", "مشابه", "مقترح", "قد يعجبك").any { parentText.contains(it) }
            if (similarHint) {
                val similarItem = MediaItem(id, match.groupValues[1], cleanTitle(title), normalizeImage(img?.attr("data-src")?.ifBlank { img?.attr("src") }), Regex("(?:19|20)\\d{2}").find(a.text())?.value.orEmpty())
                cast["__similar__${similarItem.key}"] = CastMember(name = "__SIMILAR__${similarItem.key}", character = similarItem.title, photo = similarItem.poster)
            }
        }

        val similar = cast.entries.filter { it.key.startsWith("__similar__") }.mapNotNull { entry ->
            val v = entry.value
            val key = v.name.removePrefix("__SIMILAR__")
            val parts = key.split('|')
            if (parts.size != 2) return@mapNotNull null
            val id = parts[1].toIntOrNull() ?: return@mapNotNull null
            MediaItem(id, parts[0], v.character, v.photo)
        }.distinctBy { it.key }.take(12)

        val cleanCast = cast.values.filter { !it.name.startsWith("__SIMILAR__") }.take(12)
        val o = best
        if (o == null) return item to DetailExtras(cleanCast, similar)
        val rating = o.optJSONObject("aggregateRating")?.optDouble("ratingValue")?.takeIf { !it.isNaN() }
        val seasons = o.optInt("numberOfSeasons").takeIf { it > 0 }
        val updated = item.copy(
            title = o.optString("name").ifBlank { item.title },
            overview = o.optString("description").ifBlank { item.overview },
            poster = normalizeImage(o.opt("image")) ?: item.poster,
            rating = rating ?: item.rating,
            seasons = seasons ?: item.seasons,
            year = item.year.ifBlank {
                o.optString("dateCreated").take(4).ifBlank { o.optString("releaseDate").take(4) }
            }
        )
        return updated to DetailExtras(cleanCast, similar)
    }

    private fun addActorJson(value: Any?, cast: MutableMap<String, CastMember>) {
        fun addPerson(obj: JSONObject) {
            val name = obj.optString("name").trim()
            if (name.isBlank()) return
            val id = obj.optString("url").substringAfterLast('/').toIntOrNull()
            val character = obj.optString("character").trim()
            val photo = normalizeImage(obj.opt("image"))
            cast.putIfAbsent(name.lowercase(Locale.ROOT), CastMember(id, name, character, photo))
        }
        when (value) {
            is JSONObject -> addPerson(value)
            is JSONArray -> for (i in 0 until value.length()) value.optJSONObject(i)?.let(::addPerson)
        }
    }

    private fun parseJsonObjectOrArray(raw: String): Any? {
        val cleaned = raw
            .replace("<!--", "")
            .replace("-->", "")
            .trim()
        return runCatching { JSONObject(cleaned) }.getOrNull()
            ?: runCatching { JSONArray(cleaned) }.getOrNull()
    }

    private fun JSONArray?.asSequenceSafe(): Sequence<JSONObject> = sequence {
        if (this@asSequenceSafe == null) return@sequence
        for (i in 0 until this@asSequenceSafe.length()) this@asSequenceSafe.optJSONObject(i)?.let { yield(it) }
    }

    private fun fallbackEpisodes() = (1..10).toList()

    private suspend fun findAnimeUrl(page: Int): String? = withContext(Dispatchers.IO) {
        val candidates = listOf(
            "${ApiConfig.BASE_URL}/genre/animation",
            "${ApiConfig.BASE_URL}/genre/animation?type=tv",
            "${ApiConfig.BASE_URL}/tv/genre/animation",
            "${ApiConfig.BASE_URL}/genres/animation",
            "${ApiConfig.BASE_URL}/genre/anime"
        )
        for (candidate in candidates) {
            val html = runCatching { get(candidate) }.getOrNull() ?: continue
            if (parseCards(html, "anime").size >= 3) {
                return@withContext if (candidate.contains("?")) "$candidate&page=$page" else "$candidate?page=$page"
            }
        }
        null
    }

    private fun parseCards(html: String, category: String): List<MediaItem> {
        val doc = Jsoup.parse(html)
        val seen = hashSetOf<String>()
        val result = mutableListOf<MediaItem>()
        for (a in doc.select("a[href^=/movie/], a[href^=/tv/]") ) {
            val href = a.attr("href")
            val m = Regex("^/(movie|tv)/(\\d+)").find(href) ?: continue
            val type = m.groupValues[1]
            val id = m.groupValues[2].toIntOrNull() ?: continue
            val key = "$type|$id"
            if (!seen.add(key)) continue
            val img = a.selectFirst("img")
            val title = img?.attr("alt")?.trim().orEmpty()
                .ifBlank { a.text().trim().replace(Regex("\\s+"), " ") }
                .ifBlank { "عمل #$id" }
            val poster = normalizeImage(img?.let { it.attr("data-src").ifBlank { it.attr("src") } })
            val year = Regex("(?:19|20)\\d{2}").find("$title ${a.text()}")?.value.orEmpty()
            result += MediaItem(id, type, cleanTitle(title), poster, year, sourceCategory = category)
            if (result.size >= 30) break
        }
        return result
    }

    private fun cleanTitle(title: String): String = title
        .replace(Regex("\\s+"), " ")
        .trim()
        .removePrefix("Watch ")
        .removeSuffix(" online free in HD")
        .trim()

    private fun looksLikeMedia(o: JSONObject): Boolean {
        val type = o.optString("@type")
        return type.contains("Movie", ignoreCase = true) || type.contains("TVSeries", ignoreCase = true) || type.contains("TVSeason", ignoreCase = true)
    }

    private fun looksLikeDirectStream(url: String): Boolean = Regex("\\.(m3u8|mp4)(?:$|\\?)", RegexOption.IGNORE_CASE).containsMatchIn(url)

    private fun normalizeImage(value: Any?): String? {
        val raw = when (value) {
            is String -> value
            is JSONArray -> value.optString(0)
            else -> null
        }?.trim().orEmpty()
        if (raw.isBlank()) return null
        return when {
            raw.startsWith("//") -> "https:$raw"
            raw.startsWith("/") -> ApiConfig.BASE_URL + raw
            else -> raw
        }
    }

    private fun get(url: String): String {
        val builder = Request.Builder().url(url)
        ApiConfig.headers.forEach { (k, v) -> builder.header(k, v) }
        client.newCall(builder.build()).execute().use { response ->
            if (!response.isSuccessful) error("HTTP ${response.code}")
            return response.body?.string().orEmpty()
        }
    }
}
