package com.blrx.tvmov

import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SearchBar
import androidx.compose.material3.SheetValue
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDrawerState
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import kotlinx.coroutines.launch

private enum class Screen { Home, Explore, Search, MyList, Settings, Detail, Player }
private enum class ListMode { Favorites, WatchLater, History }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TVMOVTheme { TVMOVApp() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TVMOVApp(vm: AppViewModel = viewModel()) {
    var screen by rememberSaveable { mutableStateOf(Screen.Home.name) }
    var selectedKey by rememberSaveable { mutableStateOf("") }
    var selectedSeason by rememberSaveable { mutableStateOf(1) }
    var playerUrls by rememberSaveable { mutableStateOf(listOf<String>()) }
    var playerIndex by rememberSaveable { mutableStateOf(0) }
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var detailItem by remember { mutableStateOf<MediaItem?>(null) }
    var filterOpen by rememberSaveable { mutableStateOf(false) }
    var selectedYearFilter by rememberSaveable { mutableStateOf("الكل") }
    var selectedCategory by rememberSaveable { mutableStateOf("movies") }

    val drawerState = rememberDrawerState(if (drawerOpen) DrawerValue.Open else DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val catalog by vm.catalog.collectAsState()
    val search by vm.search.collectAsState()
    val details by vm.details.collectAsState()
    val episodes by vm.episodes.collectAsState()
    val favorites by vm.favorites.collectAsState()
    val watchLater by vm.watchLater.collectAsState()
    val history by vm.history.collectAsState()

    LaunchedEffect(Unit) { vm.loadHome() }
    LaunchedEffect(details) {
        if (details != null && screen == Screen.Detail.name) detailItem = details
    }

    BackHandler(enabled = screen != Screen.Home.name || drawerState.isOpen) {
        if (drawerState.isOpen) scope.launch { drawerState.close() }
        else screen = if (screen == Screen.Detail.name || screen == Screen.Player.name) Screen.Home.name else Screen.Home.name
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier.width(320.dp)
            ) {
                Spacer(Modifier.height(22.dp))
                Text("TV MOV", fontSize = 28.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 22.dp))
                Text("سينما مرتبة وسريعة", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 22.dp, vertical = 4.dp))
                Spacer(Modifier.height(18.dp))
                DrawerItem("الرئيسية", Icons.Outlined.Home) { screen = Screen.Home.name; scope.launch { drawerState.close() } }
                DrawerItem("البحث", Icons.Outlined.Search) { screen = Screen.Search.name; scope.launch { drawerState.close() } }
                DrawerItem("قائمتي", Icons.Default.Bookmark) { screen = Screen.MyList.name; scope.launch { drawerState.close() } }
                DrawerItem("سجل المشاهدة", Icons.Default.History) { screen = Screen.MyList.name; scope.launch { drawerState.close() } }
                DrawerItem("الإعدادات", Icons.Outlined.Settings) { screen = Screen.Settings.name; scope.launch { drawerState.close() } }
                Spacer(Modifier.weight(1f))
                Text("مصدر المحتوى: watchnest.org", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.padding(22.dp))
                Spacer(Modifier.navigationBarsPadding())
            }
        }
    ) {
        when (Screen.valueOf(screen)) {
            Screen.Home -> MainScaffold(
                title = "TV MOV",
                onMenu = { scope.launch { drawerState.open() } },
                onSearch = { screen = Screen.Search.name },
                selected = "home",
                onNavigate = { target -> screen = target.name }
            ) { padding ->
                HomeScreen(
                    padding = padding,
                    catalog = catalog,
                    history = history,
                    onOpen = { item -> selectedKey = item.key; vm.open(item); detailItem = item; screen = Screen.Detail.name },
                    onCategory = { section -> selectedCategory = section.path; screen = Screen.Explore.name }
                )
            }
            Screen.Explore -> MainScaffold(
                title = "استكشاف",
                onMenu = { scope.launch { drawerState.open() } },
                onSearch = { screen = Screen.Search.name },
                selected = "explore",
                onNavigate = { target -> screen = target.name },
                actionIcon = Icons.Default.FilterList,
                onAction = { filterOpen = true }
            ) { padding ->
                ExploreScreen(
                    padding = padding,
                    catalog = catalog,
                    initialCategory = selectedCategory,
                    selectedYear = selectedYearFilter,
                    onYearChange = { selectedYearFilter = it },
                    onOpen = { item -> selectedKey = item.key; vm.open(item); detailItem = item; screen = Screen.Detail.name }
                )
            }
            Screen.Search -> MainScaffold(
                title = "بحث",
                onMenu = { scope.launch { drawerState.open() } },
                onSearch = null,
                selected = "search",
                onNavigate = { target -> screen = target.name }
            ) { padding ->
                SearchScreen(padding, searchQuery, { searchQuery = it; vm.search(it) }, search, onOpen = { item -> vm.open(item); detailItem = item; screen = Screen.Detail.name })
            }
            Screen.MyList -> MainScaffold(
                title = "قائمتي",
                onMenu = { scope.launch { drawerState.open() } },
                onSearch = { screen = Screen.Search.name },
                selected = "my",
                onNavigate = { target -> screen = target.name }
            ) { padding ->
                MyListScreen(padding, favorites, watchLater, history, onOpen = { item -> vm.open(item); detailItem = item; screen = Screen.Detail.name })
            }
            Screen.Settings -> MainScaffold(
                title = "الإعدادات",
                onMenu = { scope.launch { drawerState.open() } },
                onSearch = { screen = Screen.Search.name },
                selected = "settings",
                onNavigate = { target -> screen = target.name }
            ) { padding ->
                SettingsScreen(padding, onClearHistory = vm::clearHistory)
            }
            Screen.Detail -> {
                val item = detailItem ?: details
                if (item == null) {
                    LoadingScreen()
                } else {
                    DetailScreen(
                        item = item,
                        favorite = favorites.any { it.key == item.key },
                        watchLater = watchLater.any { it.key == item.key },
                        episodes = episodes,
                        onBack = { screen = Screen.Home.name },
                        onFavorite = { vm.toggleFavorite(item) },
                        onWatchLater = { vm.toggleWatchLater(item) },
                        onSeason = { s -> selectedSeason = s; vm.loadEpisodes(item, s) },
                        season = selectedSeason,
                        onEpisode = { e -> playerUrls = PlayerConfig.urls(item, selectedSeason, e); playerIndex = 0; screen = Screen.Player.name },
                        onMovie = { playerUrls = PlayerConfig.urls(item); playerIndex = 0; screen = Screen.Player.name }
                    )
                }
            }
            Screen.Player -> PlayerScreen(playerUrls, playerIndex, onSelect = { playerIndex = it }, onBack = { screen = Screen.Detail.name })
        }
    }

    if (filterOpen) {
        ModalBottomSheet(onDismissRequest = { filterOpen = false }, sheetState = rememberModalBottomSheetState()) {
            FilterSheet(selectedYear = selectedYearFilter, onYearChange = { selectedYearFilter = it }, onClose = { filterOpen = false })
        }
    }
}


@Composable
private fun MainScaffold(
    title: String,
    onMenu: () -> Unit,
    onSearch: (() -> Unit)?,
    selected: String,
    onNavigate: (Screen) -> Unit,
    actionIcon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    onAction: (() -> Unit)? = null,
    content: @Composable (PaddingValues) -> Unit
) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(title, fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onMenu) { Icon(Icons.Default.Menu, contentDescription = "menu") } },
                actions = {
                    if (actionIcon != null && onAction != null) IconButton(onClick = onAction) { Icon(actionIcon, contentDescription = "filter") }
                    if (onSearch != null) IconButton(onClick = onSearch) { Icon(Icons.Default.Search, contentDescription = "search") }
                    IconButton(onClick = { }) { Icon(Icons.Default.MoreVert, contentDescription = "more") }
                }
            )
        },
        bottomBar = {
            androidx.compose.material3.NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                NavigationBarItem(selected = selected == "home", onClick = { onNavigate(Screen.Home) }, icon = { Icon(if (selected == "home") Icons.Default.Home else Icons.Outlined.Home, null) }, label = { Text("الرئيسية") })
                NavigationBarItem(selected = selected == "explore", onClick = { onNavigate(Screen.Explore) }, icon = { Icon(Icons.Default.FilterList, null) }, label = { Text("استكشاف") })
                NavigationBarItem(selected = selected == "search", onClick = { onNavigate(Screen.Search) }, icon = { Icon(Icons.Default.Search, null) }, label = { Text("بحث") })
                NavigationBarItem(selected = selected == "my", onClick = { onNavigate(Screen.MyList) }, icon = { Icon(Icons.Default.Bookmark, null) }, label = { Text("قائمتي") })
                NavigationBarItem(selected = selected == "settings", onClick = { onNavigate(Screen.Settings) }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("إعدادات") })
            }
        },
        content = content
    )
}

@Composable
private fun DrawerItem(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    androidx.compose.material3.NavigationDrawerItem(
        label = { Text(title) },
        selected = false,
        onClick = onClick,
        icon = { Icon(icon, null) },
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
    )
}

@Composable
private fun HomeScreen(
    padding: PaddingValues,
    catalog: CatalogState,
    history: List<MediaItem>,
    onOpen: (MediaItem) -> Unit,
    onCategory: (HomeSection) -> Unit
) {
    LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = padding.calculateTopPadding() + 8.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            HomeHero(catalog.sections[HomeSection.Trending]?.firstOrNull(), onOpen)
        }
        if (history.isNotEmpty()) item { MediaRow("متابعة المشاهدة", history.take(10), onOpen) }
        item { TopChips(onCategory) }
        HomeSection.values().forEach { section ->
            val items = catalog.sections[section].orEmpty()
            if (items.isNotEmpty()) {
                item { MediaRow(section.label, items, onOpen) }
            }
        }
        if (catalog.loading) item { LoadingRow() }
        if (catalog.error != null) item { ErrorCard(catalog.error) }
    }
}

@Composable
private fun HomeHero(item: MediaItem?, onOpen: (MediaItem) -> Unit) {
    if (item == null) return
    Card(
        modifier = Modifier.fillMaxWidth().height(360.dp).clickable { onOpen(item) },
        shape = MaterialTheme.shapes.extraLarge,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Box(Modifier.fillMaxSize()) {
            AsyncImage(item.poster, null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xFF07080B)))))
            Column(Modifier.align(Alignment.BottomStart).padding(18.dp)) {
                Text("🔥 ترند الآن", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                Text(item.title, fontSize = 26.sp, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (item.year.isNotBlank()) Text(item.year, color = Color.LightGray)
                    if (item.rating != null) Text("★ ${String.format("%.1f", item.rating)}", color = Color.LightGray)
                }
                Spacer(Modifier.height(12.dp))
                Button(onClick = { onOpen(item) }) { Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("التفاصيل") }
            }
        }
    }
}

@Composable
private fun TopChips(onCategory: (HomeSection) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        HomeSection.values().forEach { section ->
            AssistChip(onClick = { onCategory(section) }, label = { Text(section.label) })
        }
    }
}

@Composable
private fun MediaRow(title: String, items: List<MediaItem>, onOpen: (MediaItem) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Icon(Icons.Default.ArrowForward, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(10.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(end = 4.dp)) {
            items(items, key = { it.key }) { item -> PosterCard(item, onOpen) }
        }
    }
}

@Composable
private fun PosterCard(item: MediaItem, onOpen: (MediaItem) -> Unit) {
    Column(Modifier.width(132.dp).clickable { onOpen(item) }) {
        Card(shape = MaterialTheme.shapes.large, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            AsyncImage(item.poster, null, modifier = Modifier.fillMaxWidth().aspectRatio(0.68f), contentScale = ContentScale.Crop)
        }
        Spacer(Modifier.height(6.dp))
        Text(item.title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        if (item.year.isNotBlank()) Text(item.year, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
    }
}

@Composable
private fun ExploreScreen(padding: PaddingValues, catalog: CatalogState, initialCategory: String, selectedYear: String, onYearChange: (String) -> Unit, onOpen: (MediaItem) -> Unit) {
    var category by remember { mutableStateOf(initialCategory) }
    val section = HomeSection.values().find { it.path == category } ?: HomeSection.Movies
    val source = catalog.sections[section].orEmpty()
    val filtered = source.filter { selectedYear == "الكل" || it.year == selectedYear }
    Column(Modifier.fillMaxSize().padding(top = padding.calculateTopPadding())) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HomeSection.values().forEach { s -> FilterChip(selected = section == s, onClick = { category = s.path }, label = { Text(s.label) }) }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("الكل", "2026", "2025", "2024", "2023", "2022").forEach { year ->
                FilterChip(selected = selectedYear == year, onClick = { onYearChange(year) }, label = { Text(year) })
            }
        }
        Spacer(Modifier.height(10.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(3), contentPadding = PaddingValues(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            items(filtered, key = { it.key }) { PosterCard(it, onOpen) }
        }
    }
}

@Composable
private fun SearchScreen(padding: PaddingValues, query: String, onQuery: (String) -> Unit, results: List<MediaItem>, onOpen: (MediaItem) -> Unit) {
    Column(Modifier.fillMaxSize().padding(top = padding.calculateTopPadding())) {
        SearchBar(query = query, onQueryChange = onQuery, onSearch = { onQuery(query) }, active = false, onActiveChange = { }, placeholder = { Text("ابحث عن فيلم، مسلسل…") }, leadingIcon = { Icon(Icons.Default.Search, null) }, trailingIcon = { if (query.isNotBlank()) IconButton(onClick = { onQuery("") }) { Icon(Icons.Default.Close, null) } }, modifier = Modifier.fillMaxWidth().padding(16.dp)) {}
        if (query.isBlank()) {
            Text("ابحث بالاسم كما هو في المصدر.", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
        } else if (results.isEmpty()) {
            EmptyState("لا توجد نتائج مطابقة")
        } else {
            LazyVerticalGrid(columns = GridCells.Fixed(3), contentPadding = PaddingValues(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                items(results, key = { it.key }) { PosterCard(it, onOpen) }
            }
        }
    }
}

@Composable
private fun MyListScreen(padding: PaddingValues, favorites: List<MediaItem>, watchLater: List<MediaItem>, history: List<MediaItem>, onOpen: (MediaItem) -> Unit) {
    var mode by rememberSaveable { mutableStateOf(ListMode.Favorites.name) }
    val list = when (ListMode.valueOf(mode)) { ListMode.Favorites -> favorites; ListMode.WatchLater -> watchLater; ListMode.History -> history }
    Column(Modifier.fillMaxSize().padding(top = padding.calculateTopPadding())) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = mode == ListMode.Favorites.name, onClick = { mode = ListMode.Favorites.name }, label = { Text("مفضلة (${favorites.size})") })
            FilterChip(selected = mode == ListMode.WatchLater.name, onClick = { mode = ListMode.WatchLater.name }, label = { Text("أرغب بمشاهدتها (${watchLater.size})") })
            FilterChip(selected = mode == ListMode.History.name, onClick = { mode = ListMode.History.name }, label = { Text("شاهدت (${history.size})") })
        }
        if (list.isEmpty()) EmptyState("هذه القائمة فارغة") else LazyVerticalGrid(columns = GridCells.Fixed(3), contentPadding = PaddingValues(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) { items(list, key = { it.key }) { PosterCard(it, onOpen) } }
    }
}

@Composable
private fun DetailScreen(item: MediaItem, favorite: Boolean, watchLater: Boolean, episodes: List<Int>, season: Int, onBack: () -> Unit, onFavorite: () -> Unit, onWatchLater: () -> Unit, onSeason: (Int) -> Unit, onEpisode: (Int) -> Unit, onMovie: () -> Unit) {
    val seasons = item.seasons ?: 1
    LaunchedEffect(item.key, season, item.isTv) { if (item.isTv) onSeason(season) }
    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Box(Modifier.fillMaxWidth().height(460.dp)) {
                AsyncImage(item.poster, null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x22000000), Color(0xFF080A0F)))))
                IconButton(onClick = onBack, modifier = Modifier.align(Alignment.TopStart).padding(14.dp)) { Icon(Icons.Default.ArrowBack, null) }
                Column(Modifier.align(Alignment.BottomStart).padding(18.dp)) {
                    Text(if (item.isMovie) "🎬 فيلم" else "📺 مسلسل", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text(item.title, fontSize = 30.sp, fontWeight = FontWeight.Black, maxLines = 3, overflow = TextOverflow.Ellipsis)
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(top = 8.dp)) {
                        if (item.year.isNotBlank()) Text(item.year, color = Color.LightGray)
                        item.rating?.let { Text("★ ${String.format("%.1f", it)}", color = Color.LightGray) }
                    }
                }
            }
        }
        item {
            Column(Modifier.padding(horizontal = 18.dp, vertical = 12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = onMovie, enabled = item.isMovie) { Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(4.dp)); Text("مشاهدة") }
                    OutlinedButton(onClick = onFavorite) { Icon(if (favorite) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder, null); Spacer(Modifier.width(4.dp)); Text(if (favorite) "مفضلة" else "إضافة") }
                    IconButton(onClick = onWatchLater) { Icon(Icons.Default.Visibility, null) }
                }
                Spacer(Modifier.height(14.dp))
                Text("نبذة", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Spacer(Modifier.height(6.dp))
                Text(item.overview.ifBlank { "لا يوجد وصف متاح حاليًا." }, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 22.sp)
                Spacer(Modifier.height(18.dp))
                if (item.isTv) {
                    Text("المواسم", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items((1..seasons).toList()) { s -> FilterChip(selected = season == s, onClick = { onSeason(s) }, label = { Text("الموسم $s") }) }
                    }
                    Spacer(Modifier.height(16.dp))
                    Text("الحلقات", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(episodes.ifEmpty { (1..10).toList() }) { e ->
                            AssistChip(onClick = { onEpisode(e) }, label = { Text("E$e") }, leadingIcon = { Icon(Icons.Default.PlayArrow, null) })
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PlayerScreen(urls: List<String>, selectedIndex: Int, onSelect: (Int) -> Unit, onBack: () -> Unit) {
    if (urls.isEmpty()) { EmptyState("لا يوجد مصدر مشاهدة مضبوط") ; return }
    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
            Text("المشغل", color = Color.White, fontWeight = FontWeight.Bold)
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            urls.forEachIndexed { index, _ ->
                FilterChip(selected = selectedIndex == index, onClick = { onSelect(index) }, label = { Text("السيرفر ${index + 1}") })
            }
        }
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { context ->
                WebView(context).apply {
                    webViewClient = WebViewClient()
                    webChromeClient = WebChromeClient()
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = false
                    settings.cacheMode = WebSettings.LOAD_DEFAULT
                    settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                    loadUrl(urls[selectedIndex])
                }
            },
            update = { web ->
                if (web.url != urls[selectedIndex]) web.loadUrl(urls[selectedIndex])
            }
        )
    }
}

@Composable
private fun SettingsScreen(padding: PaddingValues, onClearHistory: () -> Unit) {
    var confirm by rememberSaveable { mutableStateOf(false) }
    LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = padding.calculateTopPadding() + 12.dp, bottom = 24.dp)) {
        item {
            Text("تجربة المشاهدة", fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Spacer(Modifier.height(10.dp))
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(16.dp)) {
                    Text("الواجهة", fontWeight = FontWeight.SemiBold)
                    Text("الوضع الداكن مفعل افتراضيًا لراحة المشاهدة.", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
                }
            }
            Spacer(Modifier.height(12.dp))
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(16.dp)) {
                    Text("المصدر", fontWeight = FontWeight.SemiBold)
                    Text(ApiConfig.BASE_URL, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
                }
            }
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = { confirm = true }, modifier = Modifier.fillMaxWidth()) { Text("مسح سجل المشاهدة") }
            Spacer(Modifier.height(12.dp))
            Text("الإصدار 1.0.0", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        }
    }
    if (confirm) AlertDialog(onDismissRequest = { confirm = false }, title = { Text("مسح السجل؟") }, text = { Text("سيتم حذف قائمة الأعمال التي فتحتها محليًا فقط.") }, confirmButton = { TextButton(onClick = { onClearHistory(); confirm = false }) { Text("حذف") } }, dismissButton = { TextButton(onClick = { confirm = false }) { Text("إلغاء") } })
}

@Composable
private fun FilterSheet(selectedYear: String, onYearChange: (String) -> Unit, onClose: () -> Unit) {
    Column(Modifier.padding(20.dp)) {
        Text("الفلاتر", fontSize = 24.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(12.dp))
        Text("السنة", fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("الكل", "2026", "2025", "2024", "2023", "2022").forEach { y -> FilterChip(selected = selectedYear == y, onClick = { onYearChange(y) }, label = { Text(y) }) }
        }
        Spacer(Modifier.height(22.dp))
        Text("الترتيب", fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("أحدث • الأعلى تقييمًا • الأكثر رواجًا", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(22.dp))
        Button(onClick = onClose, modifier = Modifier.fillMaxWidth()) { Text("تطبيق") }
        Spacer(Modifier.navigationBarsPadding())
    }
}

@Composable
private fun LoadingRow() {
    Box(Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) { Text("جاري تحميل الكتالوج…", color = MaterialTheme.colorScheme.onSurfaceVariant) }
}

@Composable
private fun LoadingScreen() { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("جاري التحميل…") } }

@Composable
private fun ErrorCard(text: String?) { Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), modifier = Modifier.fillMaxWidth()) { Text(text ?: "خطأ", modifier = Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) } }

@Composable
private fun EmptyState(text: String) { Box(Modifier.fillMaxSize().padding(28.dp), contentAlignment = Alignment.Center) { Text(text, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
