@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.blrx.tvmov

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.compose.foundation.shape.CircleShape
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SheetValue
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDrawerState
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import coil.compose.LocalImageLoader
import coil.request.ImageRequest
import androidx.media3.common.MediaItem as Media3Item
import androidx.media3.common.MimeTypes
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.launch
import android.view.ViewGroup

private enum class Screen { Home, Explore, Search, MyList, Account, Settings, Detail, Player }
private enum class ListMode { Favorites, WatchLater, History }

class MainActivity : ComponentActivity() {
    private val pendingDeepLink = androidx.compose.runtime.mutableStateOf<Uri?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pendingDeepLink.value = intent?.data
        setContent { TVMOVTheme { TVMOVApp(initialDeepLink = pendingDeepLink.value) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        pendingDeepLink.value = intent.data
    }
}

@Composable
private fun TVMOVApp(initialDeepLink: Uri? = null, vm: AppViewModel = viewModel()) {
    var screen by rememberSaveable { mutableStateOf(Screen.Home.name) }
    var selectedKey by rememberSaveable { mutableStateOf("") }
    var selectedSeason by rememberSaveable { mutableStateOf(1) }
    var playerSources by remember { mutableStateOf(listOf<PlayerSource>()) }
    var playerIndex by rememberSaveable { mutableStateOf(0) }
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var detailItem by remember { mutableStateOf<MediaItem?>(null) }
    var filterOpen by rememberSaveable { mutableStateOf(false) }
    var selectedYearFilter by rememberSaveable { mutableStateOf("الكل") }
    var selectedCategory by rememberSaveable { mutableStateOf("movies") }
    var bottomBarVisible by remember { mutableStateOf(true) }
    var registrationBannerVisible by remember { mutableStateOf(true) }
    var accountMode by rememberSaveable { mutableStateOf("login") }
    var recoveryMode by rememberSaveable { mutableStateOf(false) }
    var authNotice by rememberSaveable { mutableStateOf<String?>(null) }

    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val catalog by vm.catalog.collectAsState()
    val search by vm.search.collectAsState()
    val details by vm.details.collectAsState()
    val episodes by vm.episodes.collectAsState()
    val detailExtras by vm.detailExtras.collectAsState()
    val favorites by vm.favorites.collectAsState()
    val watchLater by vm.watchLater.collectAsState()
    val history by vm.history.collectAsState()
    val loggedIn by vm.loggedIn.collectAsState()
    val profile by vm.profile.collectAsState()
    val authBusy by vm.authBusy.collectAsState()
    val authMessage by vm.authMessage.collectAsState()

    val context = LocalContext.current
    val imageLoader = LocalImageLoader.current
    LaunchedEffect(catalog.sections) {
        catalog.sections.values.flatten()
            .mapNotNull { it.poster }
            .distinct()
            .take(60)
            .forEach { url ->
                imageLoader.enqueue(ImageRequest.Builder(context).data(url).crossfade(false).build())
            }
    }

    var splashVisible by rememberSaveable { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        vm.loadHome()
        if (loggedIn) vm.loadProfile()
        kotlinx.coroutines.delay(1450)
        splashVisible = false
    }
    LaunchedEffect(initialDeepLink) {
        val deepLinkHandled = vm.handleAuthDeepLink(initialDeepLink)
        if (deepLinkHandled) { recoveryMode = true; screen = Screen.Account.name }
    }
    LaunchedEffect(loggedIn) {
        if (loggedIn) { registrationBannerVisible = false; vm.loadProfile() }
    }
    LaunchedEffect(authMessage) { if (authMessage != null) authNotice = authMessage }
    LaunchedEffect(screen) { bottomBarVisible = true }
    LaunchedEffect(details) {
        if (details != null && screen == Screen.Detail.name) detailItem = details
    }

    BackHandler(enabled = screen != Screen.Home.name || drawerState.isOpen) {
        if (drawerState.isOpen) scope.launch { drawerState.close() }
        else screen = if (screen == Screen.Detail.name || screen == Screen.Player.name) Screen.Home.name else Screen.Home.name
    }

    if (splashVisible) {
        SplashScreen()
        return
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier.width(320.dp)
            ) {
                Spacer(Modifier.height(22.dp))
                Text("TV MOV", fontSize = 28.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 22.dp))
                Text("سينما مرتبة وسريعة", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 22.dp, vertical = 4.dp))
                Spacer(Modifier.height(18.dp))
                DrawerItem("الرئيسية", Icons.Outlined.Home) { screen = Screen.Home.name; scope.launch { drawerState.close() } }
                DrawerItem("البحث", Icons.Outlined.Search) { screen = Screen.Search.name; scope.launch { drawerState.close() } }
                DrawerItem("قائمتي", Icons.Default.Bookmark) { screen = Screen.MyList.name; scope.launch { drawerState.close() } }
                DrawerItem("حسابي", Icons.Default.AccountCircle) { screen = Screen.Account.name; scope.launch { drawerState.close() } }
                DrawerItem("سجل المشاهدة", Icons.Default.History) { screen = Screen.MyList.name; scope.launch { drawerState.close() } }
                DrawerItem("الإعدادات", Icons.Outlined.Settings) { screen = Screen.Settings.name; scope.launch { drawerState.close() } }
                Spacer(Modifier.weight(1f))
                val context = LocalContext.current
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).clickable {
                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/VantaV_X")))
                    },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = MaterialTheme.shapes.large
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Column(Modifier.weight(1f)) {
                            Text("Telegram", fontWeight = FontWeight.Bold)
                            Text("@VantaV_X", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                        }
                        Icon(Icons.Default.ArrowForward, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Text("الإصدار 1.2.0", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp, modifier = Modifier.fillMaxWidth().padding(start = 22.dp, end = 22.dp, top = 4.dp), textAlign = TextAlign.Center)
                Text("by: BLRX VIP", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp, modifier = Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 2.dp), textAlign = TextAlign.Center)
                Spacer(Modifier.navigationBarsPadding())
            }
        }
    ) {
        when (Screen.valueOf(screen)) {
            Screen.Home -> MainScaffold(
                title = "TV MOV",
                onMenu = { scope.launch { drawerState.open() } },
                onSearch = { screen = Screen.Search.name },
                selected = "home",
                onNavigate = { target -> screen = target.name },
                bottomBarVisible = bottomBarVisible
            ) { padding ->
                HomeScreen(
                    padding = padding,
                    catalog = catalog,
                    history = history,
                    onOpen = { item -> selectedKey = item.key; vm.open(item); detailItem = item; screen = Screen.Detail.name },
                    onCategory = { section -> selectedCategory = section.path; screen = Screen.Explore.name },
                    onScrollDirection = { down -> bottomBarVisible = !down },
                    showRegistrationBanner = registrationBannerVisible && !loggedIn,
                    onDismissRegistrationBanner = { registrationBannerVisible = false },
                    onRegister = { screen = Screen.Account.name; accountMode = "login" }
                )
            }
            Screen.Explore -> MainScaffold(
                title = "استكشاف",
                onMenu = { scope.launch { drawerState.open() } },
                onSearch = { screen = Screen.Search.name },
                selected = "explore",
                onNavigate = { target -> screen = target.name },
                actionIcon = Icons.Default.FilterList,
                onAction = { filterOpen = true }
            ) { padding ->
                ExploreScreen(
                    padding = padding,
                    catalog = catalog,
                    initialCategory = selectedCategory,
                    selectedYear = selectedYearFilter,
                    onYearChange = { selectedYearFilter = it },
                    onOpen = { item -> selectedKey = item.key; vm.open(item); detailItem = item; screen = Screen.Detail.name },
                    onScrollDirection = { down -> bottomBarVisible = !down }
                )
            }
            Screen.Search -> MainScaffold(
                title = "بحث",
                onMenu = { scope.launch { drawerState.open() } },
                onSearch = null,
                selected = "search",
                onNavigate = { target -> screen = target.name },
                bottomBarVisible = bottomBarVisible
            ) { padding ->
                SearchScreen(padding, searchQuery, { searchQuery = it; vm.search(it) }, search, onOpen = { item -> vm.open(item); detailItem = item; screen = Screen.Detail.name }, onScrollDirection = { down -> bottomBarVisible = !down })
            }
            Screen.MyList -> MainScaffold(
                title = "قائمتي",
                onMenu = { scope.launch { drawerState.open() } },
                onSearch = { screen = Screen.Search.name },
                selected = "my",
                onNavigate = { target -> screen = target.name },
                bottomBarVisible = bottomBarVisible
            ) { padding ->
                MyListScreen(padding, favorites, watchLater, history, onOpen = { item -> vm.open(item); detailItem = item; screen = Screen.Detail.name }, onScrollDirection = { down -> bottomBarVisible = !down })
            }
            Screen.Account -> AccountScreen(
                loggedIn = loggedIn,
                profile = profile,
                mode = accountMode,
                recoveryMode = recoveryMode,
                busy = authBusy,
                notice = authNotice,
                onClearNotice = { authNotice = null; vm.clearAuthMessage() },
                onModeChange = { accountMode = it; recoveryMode = false; authNotice = null; vm.clearAuthMessage() },
                onRecoveryMode = { recoveryMode = true; accountMode = "login"; authNotice = null; vm.clearAuthMessage() },
                onSignIn = { email, password -> vm.signIn(email, password) },
                onSignUp = { email, password, username -> vm.signUp(email, password, username) },
                onRecover = { email -> vm.recover(email) },
                onUpdatePassword = { password -> vm.updatePassword(password) },
                onSignOut = { vm.signOut() },
                onUpdateProfile = { name, avatar, cover -> vm.updateProfile(name, avatar, cover) },
                onUploadImage = { bytes, mime, ext -> vm.uploadProfileImage(bytes, mime, ext) },
                favorites = favorites,
                watchLater = watchLater,
                history = history,
                onOpen = { item -> vm.open(item); detailItem = item; screen = Screen.Detail.name },
                onBack = { screen = Screen.Home.name }
            )
            Screen.Settings -> MainScaffold(
                title = "الإعدادات",
                onMenu = { scope.launch { drawerState.open() } },
                onSearch = { screen = Screen.Search.name },
                selected = "settings",
                onNavigate = { target -> screen = target.name },
                bottomBarVisible = bottomBarVisible
            ) { padding ->
                SettingsScreen(padding, onClearHistory = vm::clearHistory)
            }
            Screen.Detail -> {
                val item = detailItem ?: details
                if (item == null) {
                    LoadingScreen()
                } else {
                    DetailScreen(
                        item = item,
                        favorite = favorites.any { it.key == item.key },
                        watchLater = watchLater.any { it.key == item.key },
                        episodes = episodes,
                        cast = detailExtras.cast,
                        similar = detailExtras.similar,
                        onOpenSimilar = { item -> vm.open(item); detailItem = item; screen = Screen.Detail.name },
                        onBack = { screen = Screen.Home.name },
                        onFavorite = { vm.toggleFavorite(item) },
                        onWatchLater = { vm.toggleWatchLater(item) },
                        onSeason = { s -> selectedSeason = s; vm.loadEpisodes(item, s) },
                        season = selectedSeason,
                        onEpisode = { e -> playerSources = PlayerConfig.urls(item, selectedSeason, e); playerIndex = 0; screen = Screen.Player.name },
                        onMovie = { playerSources = PlayerConfig.urls(item); playerIndex = 0; screen = Screen.Player.name }
                    )
                }
            }
            Screen.Player -> PlayerScreen(playerSources, playerIndex, onSelect = { playerIndex = it }, onResolve = vm::resolveDirectPlayer, onBack = { screen = Screen.Detail.name })
        }
    }

    if (filterOpen) {
        ModalBottomSheet(onDismissRequest = { filterOpen = false }, sheetState = rememberModalBottomSheetState()) {
            FilterSheet(selectedYear = selectedYearFilter, onYearChange = { selectedYearFilter = it }, onClose = { filterOpen = false })
        }
    }
}


@Composable
private fun SplashScreen() {
    Box(Modifier.fillMaxSize().background(Color(0xFF07090E)), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Surface(shape = CircleShape, color = Color(0xFF151922), tonalElevation = 10.dp, modifier = Modifier.size(132.dp)) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("TV", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Black)
                    Text("MOV", color = MaterialTheme.colorScheme.primary, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 64.dp))
                }
            }
            Spacer(Modifier.height(22.dp))
            Text("TV MOV", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(10.dp))
            Text("الإصدار 1.2.0", color = Color(0xFF9DA5B2), fontSize = 11.sp)
            Text("by: BLRX VIP", color = Color(0xFF6F7787), fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
private fun MainScaffold(
    title: String,
    onMenu: () -> Unit,
    onSearch: (() -> Unit)?,
    selected: String,
    onNavigate: (Screen) -> Unit,
    actionIcon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    onAction: (() -> Unit)? = null,
    bottomBarVisible: Boolean = true,
    content: @Composable (PaddingValues) -> Unit
) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Surface(color = MaterialTheme.colorScheme.background) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onMenu) { Icon(Icons.Default.Menu, contentDescription = "menu") }
                    Text(title, modifier = Modifier.weight(1f), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    if (actionIcon != null && onAction != null) {
                        IconButton(onClick = onAction) { Icon(actionIcon, contentDescription = "filter") }
                    }
                    if (onSearch != null) {
                        IconButton(onClick = onSearch) { Icon(Icons.Default.Search, contentDescription = "search") }
                    }
                    IconButton(onClick = onMenu) { Icon(Icons.Default.MoreVert, contentDescription = "القائمة") }
                }
            }
        },
        bottomBar = {
            androidx.compose.animation.AnimatedVisibility(
                visible = bottomBarVisible,
                enter = androidx.compose.animation.slideInVertically { it } + fadeIn(),
                exit = androidx.compose.animation.slideOutVertically { it } + fadeOut()
            ) {
                androidx.compose.material3.NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    NavigationBarItem(selected = selected == "home", onClick = { onNavigate(Screen.Home) }, icon = { Icon(if (selected == "home") Icons.Default.Home else Icons.Outlined.Home, null) }, label = { Text("الرئيسية") })
                    NavigationBarItem(selected = selected == "explore", onClick = { onNavigate(Screen.Explore) }, icon = { Icon(Icons.Default.FilterList, null) }, label = { Text("استكشاف") })
                    NavigationBarItem(selected = selected == "my", onClick = { onNavigate(Screen.MyList) }, icon = { Icon(Icons.Default.Bookmark, null) }, label = { Text("قائمتي") })
                    NavigationBarItem(selected = selected == "account", onClick = { onNavigate(Screen.Account) }, icon = { Icon(Icons.Default.AccountCircle, null) }, label = { Text("حسابي") })
                }
            }
        },
        content = content
    )
}

@Composable
private fun DrawerItem(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    androidx.compose.material3.NavigationDrawerItem(
        label = { Text(title) },
        selected = false,
        onClick = onClick,
        icon = { Icon(icon, null) },
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
    )
}

@Composable
private fun HomeScreen(
    padding: PaddingValues,
    catalog: CatalogState,
    history: List<MediaItem>,
    onOpen: (MediaItem) -> Unit,
    onCategory: (HomeSection) -> Unit,
    onScrollDirection: (Boolean) -> Unit,
    showRegistrationBanner: Boolean,
    onDismissRegistrationBanner: () -> Unit,
    onRegister: () -> Unit
) {
    val listState = rememberLazyListState()
    var previousOffset by remember { mutableStateOf(0) }
    LaunchedEffect(listState.firstVisibleItemIndex, listState.firstVisibleItemScrollOffset) {
        val current = listState.firstVisibleItemIndex * 100000 + listState.firstVisibleItemScrollOffset
        if (current > previousOffset + 4) onScrollDirection(true) else if (current < previousOffset - 4) onScrollDirection(false)
        previousOffset = current
    }
    LazyColumn(state = listState, contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = padding.calculateTopPadding() + 8.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        if (showRegistrationBanner) item { RegistrationBanner(onRegister, onDismissRegistrationBanner) }
        item {
            val heroItems = buildList {
                addAll(catalog.sections[HomeSection.Trending].orEmpty())
                addAll(catalog.sections[HomeSection.Anime].orEmpty())
                addAll(catalog.sections[HomeSection.Series].orEmpty())
                addAll(catalog.sections[HomeSection.Movies].orEmpty())
            }.distinctBy { it.key }.take(12)
            HomeHero(heroItems, onOpen)
        }
        if (history.isNotEmpty()) item { MediaRow("متابعة المشاهدة", history.take(10), onOpen) {} }
        item { TopChips(onCategory) }
        HomeSection.values().forEach { section ->
            val items = catalog.sections[section].orEmpty()
            if (items.isNotEmpty()) {
                item { MediaRow(section.label, items, onOpen) { onCategory(section) } }
            }
        }
        if (catalog.error != null) item { ErrorCard(catalog.error) }
    }
}

@Composable
private fun HomeHero(items: List<MediaItem>, onOpen: (MediaItem) -> Unit) {
    if (items.isEmpty()) return
    var index by rememberSaveable(items.map { it.key }) { mutableStateOf(0) }
    LaunchedEffect(items.map { it.key }) {
        while (true) {
            kotlinx.coroutines.delay(5500)
            index = (index + 1) % items.size
        }
    }
    val item = items[index.coerceIn(0, items.lastIndex)]
    AnimatedContent(targetState = item.key, label = "hero") {
        Card(
            modifier = Modifier.fillMaxWidth().height(360.dp),
            shape = MaterialTheme.shapes.extraLarge,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            onClick = { onOpen(item) }
        ) {
            Box(Modifier.fillMaxSize()) {
                PosterImage(item.poster, Modifier.fillMaxSize(), ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xFF07080B)))))
                Column(Modifier.align(Alignment.BottomStart).padding(18.dp)) {
                    Text("ترند اليوم", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text(item.title, fontSize = 26.sp, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (item.year.isNotBlank()) Text(item.year, color = Color.LightGray)
                        if (item.rating != null) Text("★ ${String.format("%.1f", item.rating)}", color = Color.LightGray)
                    }
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { onOpen(item) }) { Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("التفاصيل") }
                }
            }
        }
    }
}

@Composable
private fun TopChips(onCategory: (HomeSection) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        HomeSection.values().forEach { section ->
            AssistChip(onClick = { onCategory(section) }, label = { Text(section.label) })
        }
    }
}

@Composable
private fun MediaRow(title: String, items: List<MediaItem>, onOpen: (MediaItem) -> Unit, onMore: () -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            IconButton(onClick = onMore) { Icon(Icons.Default.ArrowForward, contentDescription = "المزيد", tint = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        Spacer(Modifier.height(10.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(end = 4.dp)) {
            items(items, key = { it.key }) { item -> PosterCard(item, onOpen) }
        }
    }
}

@Composable
private fun PosterCard(item: MediaItem, onOpen: (MediaItem) -> Unit) {
    Column(Modifier.width(132.dp).clickable { onOpen(item) }) {
        Card(shape = MaterialTheme.shapes.large, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            PosterImage(item.poster, Modifier.fillMaxWidth().aspectRatio(0.68f), ContentScale.Crop)
        }
        Spacer(Modifier.height(6.dp))
        Text(item.title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        if (item.year.isNotBlank()) Text(item.year, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
    }
}

@Composable
private fun PosterImage(url: String?, modifier: Modifier, contentScale: ContentScale) {
    val context = LocalContext.current
    val request = remember(url) {
        ImageRequest.Builder(context)
            .data(url)
            .crossfade(false)
            .memoryCacheKey(url ?: "blank")
            .diskCacheKey(url ?: "blank")
            .build()
    }
    AsyncImage(
        model = request,
        contentDescription = null,
        modifier = modifier,
        contentScale = contentScale
    )
}

@Composable
private fun ExploreScreen(padding: PaddingValues, catalog: CatalogState, initialCategory: String, selectedYear: String, onYearChange: (String) -> Unit, onOpen: (MediaItem) -> Unit, onScrollDirection: (Boolean) -> Unit) {
    var category by remember { mutableStateOf(initialCategory) }
    val section = HomeSection.values().find { it.path == category } ?: HomeSection.Movies
    val source = catalog.sections[section].orEmpty()
    val filtered = source.filter { selectedYear == "الكل" || it.year == selectedYear }
    Column(Modifier.fillMaxSize().padding(top = padding.calculateTopPadding())) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HomeSection.values().forEach { s -> FilterChip(selected = section == s, onClick = { category = s.path }, label = { Text(s.label) }) }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("الكل", "2026", "2025", "2024", "2023", "2022").forEach { year ->
                FilterChip(selected = selectedYear == year, onClick = { onYearChange(year) }, label = { Text(year) })
            }
        }
        Spacer(Modifier.height(10.dp))
        val gridState = rememberLazyGridState()
        var previousIndex by remember { mutableStateOf(0) }
        LaunchedEffect(gridState.firstVisibleItemIndex) {
            if (gridState.firstVisibleItemIndex > previousIndex) onScrollDirection(true) else if (gridState.firstVisibleItemIndex < previousIndex) onScrollDirection(false)
            previousIndex = gridState.firstVisibleItemIndex
        }
        LazyVerticalGrid(state = gridState, columns = GridCells.Fixed(3), contentPadding = PaddingValues(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            items(filtered, key = { it.key }) { PosterCard(it, onOpen) }
        }
    }
}

@Composable
private fun SearchScreen(padding: PaddingValues, query: String, onQuery: (String) -> Unit, results: List<MediaItem>, onOpen: (MediaItem) -> Unit, onScrollDirection: (Boolean) -> Unit) {
    Column(Modifier.fillMaxSize().padding(top = padding.calculateTopPadding())) {
        androidx.compose.material3.OutlinedTextField(
            value = query,
            onValueChange = onQuery,
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            singleLine = true,
            placeholder = { Text("ابحث عن فيلم، مسلسل…") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            trailingIcon = { if (query.isNotBlank()) IconButton(onClick = { onQuery("") }) { Icon(Icons.Default.Close, null) } }
        )
        if (query.isBlank()) {
            Text("اكتب اسم الفيلم أو المسلسل للبحث السريع.", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
        } else if (results.isEmpty()) {
            EmptyState("لا توجد نتائج مطابقة")
        } else {
            val gridState = rememberLazyGridState()
            var previousIndex by remember { mutableStateOf(0) }
            LaunchedEffect(gridState.firstVisibleItemIndex) {
                if (gridState.firstVisibleItemIndex > previousIndex) onScrollDirection(true) else if (gridState.firstVisibleItemIndex < previousIndex) onScrollDirection(false)
                previousIndex = gridState.firstVisibleItemIndex
            }
            LazyVerticalGrid(state = gridState, columns = GridCells.Fixed(3), contentPadding = PaddingValues(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                items(results, key = { it.key }) { PosterCard(it, onOpen) }
            }
        }
    }
}

@Composable
private fun MyListScreen(padding: PaddingValues, favorites: List<MediaItem>, watchLater: List<MediaItem>, history: List<MediaItem>, onOpen: (MediaItem) -> Unit, onScrollDirection: (Boolean) -> Unit) {
    var mode by rememberSaveable { mutableStateOf(ListMode.Favorites.name) }
    val list = when (ListMode.valueOf(mode)) { ListMode.Favorites -> favorites; ListMode.WatchLater -> watchLater; ListMode.History -> history }
    Column(Modifier.fillMaxSize().padding(top = padding.calculateTopPadding())) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = mode == ListMode.Favorites.name, onClick = { mode = ListMode.Favorites.name }, label = { Text("مفضلة (${favorites.size})") })
            FilterChip(selected = mode == ListMode.WatchLater.name, onClick = { mode = ListMode.WatchLater.name }, label = { Text("أرغب بمشاهدتها (${watchLater.size})") })
            FilterChip(selected = mode == ListMode.History.name, onClick = { mode = ListMode.History.name }, label = { Text("شاهدت (${history.size})") })
        }
        if (list.isEmpty()) EmptyState("هذه القائمة فارغة") else {
            val gridState = rememberLazyGridState()
            var previousIndex by remember { mutableStateOf(0) }
            LaunchedEffect(gridState.firstVisibleItemIndex) {
                if (gridState.firstVisibleItemIndex > previousIndex) onScrollDirection(true) else if (gridState.firstVisibleItemIndex < previousIndex) onScrollDirection(false)
                previousIndex = gridState.firstVisibleItemIndex
            }
            LazyVerticalGrid(state = gridState, columns = GridCells.Fixed(3), contentPadding = PaddingValues(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) { items(list, key = { it.key }) { PosterCard(it, onOpen) } }
        }
    }
}

@Composable
private fun DetailScreen(
    item: MediaItem,
    favorite: Boolean,
    watchLater: Boolean,
    episodes: List<Int>,
    cast: List<CastMember>,
    similar: List<MediaItem>,
    onOpenSimilar: (MediaItem) -> Unit,
    season: Int,
    onBack: () -> Unit,
    onFavorite: () -> Unit,
    onWatchLater: () -> Unit,
    onSeason: (Int) -> Unit,
    onEpisode: (Int) -> Unit,
    onMovie: () -> Unit
) {
    val seasons = item.seasons ?: 1
    LaunchedEffect(item.key, season, item.isTv) { if (item.isTv) onSeason(season) }
    LazyColumn(contentPadding = PaddingValues(bottom = 30.dp)) {
        item {
            Box(Modifier.fillMaxWidth().height(450.dp)) {
                PosterImage(item.poster, Modifier.fillMaxSize(), ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xFF080A0F)))))
                IconButton(onClick = onBack, modifier = Modifier.align(Alignment.TopStart).padding(14.dp)) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "رجوع", tint = Color.White)
                }
                Column(Modifier.align(Alignment.BottomStart).padding(20.dp)) {
                    Text(if (item.isMovie) "فيلم" else "مسلسل", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text(item.title, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black, maxLines = 3, overflow = TextOverflow.Ellipsis)
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.padding(top = 8.dp)) {
                        if (item.year.isNotBlank()) Text(item.year, color = Color.LightGray)
                        item.rating?.let { Text("★ ${String.format("%.1f", it)}", color = Color.LightGray) }
                        Text(if (item.isMovie) "فيلم" else "مسلسل", color = Color.LightGray)
                    }
                }
            }
        }
        item {
            Column(Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = onMovie, enabled = item.isMovie, modifier = Modifier.height(46.dp)) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("مشاهدة")
                    }
                    OutlinedButton(onClick = onFavorite, modifier = Modifier.height(46.dp)) {
                        Icon(if (favorite) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text(if (favorite) "مفضلة" else "إضافة")
                    }
                    OutlinedButton(onClick = onWatchLater, modifier = Modifier.height(46.dp)) {
                        Icon(Icons.Default.Visibility, contentDescription = null, tint = if (watchLater) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                        Spacer(Modifier.width(6.dp))
                        Text(if (watchLater) "مضاف للمشاهدة" else "أريد مشاهدتها")
                    }
                }
                Spacer(Modifier.height(18.dp))
                SectionTitle("نبذة")
                Spacer(Modifier.height(7.dp))
                Text(item.overview.ifBlank { "لا يوجد وصف متاح حاليًا." }, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 23.sp)
            }
        }
        if (cast.isNotEmpty()) {
            item { CastRow(cast) }
        }
        if (item.isTv) {
            item {
                Column(Modifier.padding(horizontal = 18.dp, vertical = 10.dp)) {
                    SectionTitle("المواسم")
                    Spacer(Modifier.height(9.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items((1..seasons).toList()) { s ->
                            FilterChip(selected = season == s, onClick = { onSeason(s) }, label = { Text("الموسم $s") })
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    SectionTitle("الحلقات")
                    Spacer(Modifier.height(9.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(episodes.ifEmpty { (1..10).toList() }) { e ->
                            AssistChip(onClick = { onEpisode(e) }, label = { Text("الحلقة $e") }, leadingIcon = { Icon(Icons.Default.PlayArrow, null) })
                        }
                    }
                }
            }
        }
        if (similar.isNotEmpty()) {
            item { MediaRow("أعمال مشابهة", similar, onOpen = onOpenSimilar, onMore = {}) }
        }
    }
}

@Composable
private fun CastRow(cast: List<CastMember>) {
    Column(Modifier.padding(vertical = 10.dp)) {
        SectionTitle("الممثلون", Modifier.padding(horizontal = 18.dp))
        Spacer(Modifier.height(12.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            items(cast, key = { "cast-${it.id ?: it.name}" }) { actor ->
                Column(Modifier.width(76.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Card(shape = CircleShape, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        if (actor.photo.isNullOrBlank()) {
                            Box(Modifier.size(68.dp), contentAlignment = Alignment.Center) {
                                Text(actor.name.take(1).uppercase(), color = MaterialTheme.colorScheme.primary, fontSize = 22.sp, fontWeight = FontWeight.Black)
                            }
                        } else {
                            PosterImage(actor.photo, Modifier.size(68.dp), ContentScale.Crop)
                        }
                    }
                    Spacer(Modifier.height(7.dp))
                    Text(actor.name, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    if (actor.character.isNotBlank()) Text(actor.character, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String, modifier: Modifier = Modifier) {
    Text(title, modifier = modifier, fontWeight = FontWeight.ExtraBold, fontSize = 19.sp)
}

@Composable
private fun PlayerScreen(
    sources: List<PlayerSource>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    onResolve: suspend (PlayerSource) -> PlayerSource,
    onBack: () -> Unit
) {
    if (sources.isEmpty()) { EmptyState("لا يوجد مشغل متاح حاليًا"); return }
    val safeIndex = selectedIndex.coerceIn(0, sources.lastIndex)
    val selected = sources[safeIndex]
    var resolved by remember(selected.url) { mutableStateOf<PlayerSource?>(null) }
    var resolving by remember(selected.url) { mutableStateOf(true) }
    LaunchedEffect(selected.url) {
        resolving = true
        resolved = onResolve(selected)
        resolving = false
    }
    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "رجوع", tint = Color.White) }
            Column(Modifier.weight(1f)) {
                Text("المشاهدة", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("مشغل احترافي مع دعم أصلي عند توفر رابط مباشر", color = Color(0xFF9DA5B2), fontSize = 11.sp)
            }
        }
        Box(Modifier.fillMaxWidth().padding(horizontal = 10.dp).clip(MaterialTheme.shapes.large).aspectRatio(16f / 9f).background(Color(0xFF0A0C11))) {
            when {
                resolving -> PlayerPlaceholder()
                resolved?.direct == true -> NativeVideoPlayer(resolved!!.url)
                else -> EmbedWebPlayer(resolved?.url ?: selected.url)
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("اختيار المشغل", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 14.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            sources.indices.forEach { index ->
                FilterChip(selected = safeIndex == index, onClick = { onSelect(index) }, label = { Text(sources[index].label) })
            }
        }
        Spacer(Modifier.weight(1f))
    }
}

@Composable
private fun PlayerPlaceholder() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            androidx.compose.material3.CircularProgressIndicator()
            Spacer(Modifier.height(10.dp))
            Text("تهيئة المشغل…", color = Color.White, fontSize = 12.sp)
        }
    }
}

@Composable
private fun NativeVideoPlayer(url: String) {
    val context = LocalContext.current
    val player = remember(url) {
        val okHttpClient = okhttp3.OkHttpClient.Builder()
            .addInterceptor { chain ->
                chain.proceed(
                    chain.request().newBuilder()
                        .header("User-Agent", ApiConfig.USER_AGENT)
                        .header("Referer", ApiConfig.BASE_URL + "/")
                        .build()
                )
            }
            .build()
        val dataSourceFactory = androidx.media3.datasource.okhttp.OkHttpDataSource.Factory(okHttpClient)
        val mediaSourceFactory = androidx.media3.exoplayer.hls.HlsMediaSource.Factory(dataSourceFactory)
        ExoPlayer.Builder(context)
            .setMediaSourceFactory(mediaSourceFactory)
            .build()
            .apply {
                val mime = when {
                    Regex("\\.m3u8(?:$|\\?)", RegexOption.IGNORE_CASE).containsMatchIn(url) -> MimeTypes.APPLICATION_M3U8
                    Regex("\\.mp4(?:$|\\?)", RegexOption.IGNORE_CASE).containsMatchIn(url) -> MimeTypes.VIDEO_MP4
                    else -> null
                }
                val itemBuilder = Media3Item.Builder().setUri(url)
                if (mime != null) itemBuilder.setMimeType(mime)
                setMediaItem(itemBuilder.build())
                prepare()
                playWhenReady = true
            }
    }
    DisposableEffect(player) {
        onDispose { player.release() }
    }
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { ctx ->
            PlayerView(ctx).apply {
                useController = true
                controllerShowTimeoutMs = 3500
                setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            }
        },
        update = { it.player = player }
    )
}

@Composable
private fun EmbedWebPlayer(url: String) {
    val embedHeaders = mapOf(
        "Referer" to ApiConfig.BASE_URL + "/",
        "User-Agent" to ApiConfig.USER_AGENT,
        "Accept-Language" to "ar,en;q=0.9"
    )
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { viewContext ->
            WebView(viewContext).apply {
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    databaseEnabled = true
                    mediaPlaybackRequiresUserGesture = false
                    loadsImagesAutomatically = true
                    allowFileAccess = false
                    allowContentAccess = true
                    cacheMode = WebSettings.LOAD_DEFAULT
                    // CRITICAL: allow mixed HTTP/HTTPS content so video streams load
                    mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                    // Proper viewport so embed player renders at full size
                    useWideViewPort = true
                    loadWithOverviewMode = true
                    // Set browser-like User-Agent to avoid bot detection
                    userAgentString = ApiConfig.USER_AGENT
                    setSupportZoom(false)
                    builtInZoomControls = false
                    displayZoomControls = false
                }
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(
                        view: WebView,
                        request: android.webkit.WebResourceRequest
                    ): Boolean {
                        // Stay within WebView; don't open external browser
                        return false
                    }
                }
                webChromeClient = WebChromeClient()
                setBackgroundColor(android.graphics.Color.BLACK)
                loadUrl(url, embedHeaders)
            }
        },
        update = { web ->
            if (web.url != url) web.loadUrl(url, embedHeaders)
        }
    )
}

@Composable
private fun SettingsScreen(padding: PaddingValues, onClearHistory: () -> Unit) {
    var confirm by rememberSaveable { mutableStateOf(false) }
    LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = padding.calculateTopPadding() + 12.dp, bottom = 24.dp)) {
        item {
            Text("تجربة المشاهدة", fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Spacer(Modifier.height(10.dp))
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(16.dp)) {
                    Text("الوضع الداكن", fontWeight = FontWeight.SemiBold)
                    Text("مفعل افتراضيًا لراحة المشاهدة.", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
                }
            }
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = { confirm = true }, modifier = Modifier.fillMaxWidth()) { Text("مسح سجل المشاهدة") }
            Spacer(Modifier.height(24.dp))
            Text("الإصدار 1.2.0", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            Text("by: BLRX VIP", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.fillMaxWidth().padding(top = 4.dp), textAlign = TextAlign.Center)
        }
    }
    if (confirm) AlertDialog(onDismissRequest = { confirm = false }, title = { Text("مسح السجل؟") }, text = { Text("سيتم حذف سجل المشاهدة المحفوظ على هذا الجهاز.") }, confirmButton = { TextButton(onClick = { onClearHistory(); confirm = false }) { Text("حذف") } }, dismissButton = { TextButton(onClick = { confirm = false }) { Text("إلغاء") } })
}

@Composable
private fun FilterSheet(selectedYear: String, onYearChange: (String) -> Unit, onClose: () -> Unit) {
    Column(Modifier.padding(20.dp)) {
        Text("الفلاتر", fontSize = 24.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(12.dp))
        Text("السنة", fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("الكل", "2026", "2025", "2024", "2023", "2022").forEach { y -> FilterChip(selected = selectedYear == y, onClick = { onYearChange(y) }, label = { Text(y) }) }
        }
        Spacer(Modifier.height(22.dp))
        Text("الترتيب", fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("أحدث • الأعلى تقييمًا • الأكثر رواجًا", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(22.dp))
        Button(onClick = onClose, modifier = Modifier.fillMaxWidth()) { Text("تطبيق") }
        Spacer(Modifier.navigationBarsPadding())
    }
}

@Composable
private fun LoadingScreen() { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("جاري التحميل…") } }

@Composable
private fun ErrorCard(text: String?) { Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), modifier = Modifier.fillMaxWidth()) { Text(text ?: "خطأ", modifier = Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) } }

@Composable
private fun EmptyState(text: String) { Box(Modifier.fillMaxSize().padding(28.dp), contentAlignment = Alignment.Center) { Text(text, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant) } }

@Composable
private fun RegistrationBanner(onRegister: () -> Unit, onDismiss: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = MaterialTheme.shapes.large
    ) {
        Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 6.dp, top = 10.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("لم تسجل بعد؟", fontWeight = FontWeight.Bold)
                Text("سجل الآن لحفظ قائمتك ومشاهدتك على حسابك.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Button(onClick = onRegister, colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = Color(0xFF22C55E), contentColor = Color.Black), modifier = Modifier.height(40.dp)) { Text("سجل") }
            IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "إغلاق") }
        }
    }
}

@Composable
private fun AccountScreen(
    loggedIn: Boolean,
    profile: SupabaseClient.Profile?,
    mode: String,
    recoveryMode: Boolean,
    busy: Boolean,
    notice: String?,
    onClearNotice: () -> Unit,
    onModeChange: (String) -> Unit,
    onRecoveryMode: () -> Unit,
    onSignIn: (String, String) -> Unit,
    onSignUp: (String, String, String) -> Unit,
    onRecover: (String) -> Unit,
    onUpdatePassword: (String) -> Unit,
    onSignOut: () -> Unit,
    onUpdateProfile: (String, String?, String?) -> Unit,
    onUploadImage: suspend (ByteArray, String, String) -> Result<String>,
    favorites: List<MediaItem>,
    watchLater: List<MediaItem>,
    history: List<MediaItem>,
    onOpen: (MediaItem) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var username by remember(profile?.username) { mutableStateOf(profile?.username ?: "مستخدم TV MOV") }
    var avatar by remember(profile?.avatarUrl) { mutableStateOf(profile?.avatarUrl) }
    var cover by remember(profile?.coverUrl) { mutableStateOf(profile?.coverUrl) }
    var email by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var password2 by rememberSaveable { mutableStateOf("") }
    var showPassword by rememberSaveable { mutableStateOf(false) }
    var uploading by remember { mutableStateOf(false) }
    var uploadTarget by remember { mutableStateOf("avatar") }
    val scope = rememberCoroutineScope()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        val target = uploadTarget
        // Actual upload is launched from a small coroutine owned by this composition.
        scope.launch {
            uploading = true
            try {
                val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: byteArrayOf()
                val mime = context.contentResolver.getType(uri) ?: "image/jpeg"
                val ext = mime.substringAfter('/', "jpg")
                val result = onUploadImage(bytes, mime, ext)
                result.onSuccess { url -> if (target == "avatar") avatar = url else cover = url }
                    .onFailure { /* surfaced on next profile save if needed */ }
            } finally { uploading = false }
        }
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        if (!loggedIn) {
            Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "رجوع") }
                    Text("حسابي", fontSize = 25.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                }
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = MaterialTheme.shapes.extraLarge) {
                    Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.size(96.dp)) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("TV", fontSize = 28.sp, fontWeight = FontWeight.Black) }
                        }
                        Spacer(Modifier.height(12.dp))
                        Text("TV MOV", fontSize = 25.sp, fontWeight = FontWeight.Black)
                        Text("احفظ أفلامك ومفضلاتك ومشاهدتك على حسابك.", color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center, fontSize = 13.sp)
                    }
                }
                if (mode == "signup") Text("إنشاء حساب", fontSize = 22.sp, fontWeight = FontWeight.Black)
                else if (mode == "recovery") Text("استعادة الحساب", fontSize = 22.sp, fontWeight = FontWeight.Black)
                else Text("تسجيل الدخول", fontSize = 22.sp, fontWeight = FontWeight.Black)

                if (mode == "recovery") {
                    OutlinedTextField(value = email, onValueChange = { email = it }, modifier = Modifier.fillMaxWidth(), label = { Text("البريد الإلكتروني") }, singleLine = true)
                    Button(onClick = { onRecover(email) }, enabled = !busy && email.isNotBlank(), modifier = Modifier.fillMaxWidth().height(50.dp)) { Text(if (busy) "جارٍ الإرسال…" else "إرسال رابط الاستعادة") }
                    TextButton(onClick = { onModeChange("login") }) { Text("العودة لتسجيل الدخول") }
                } else {
                    if (mode == "signup") OutlinedTextField(value = username, onValueChange = { username = it }, modifier = Modifier.fillMaxWidth(), label = { Text("اسم المستخدم") }, singleLine = true)
                    OutlinedTextField(value = email, onValueChange = { email = it }, modifier = Modifier.fillMaxWidth(), label = { Text("البريد الإلكتروني") }, singleLine = true)
                    OutlinedTextField(value = password, onValueChange = { password = it }, modifier = Modifier.fillMaxWidth(), label = { Text("كلمة المرور") }, singleLine = true, visualTransformation = if (showPassword) androidx.compose.ui.text.input.VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(), trailingIcon = { TextButton(onClick = { showPassword = !showPassword }) { Text(if (showPassword) "إخفاء" else "إظهار") } })
                    if (mode == "signup") OutlinedTextField(value = password2, onValueChange = { password2 = it }, modifier = Modifier.fillMaxWidth(), label = { Text("تأكيد كلمة المرور") }, singleLine = true, visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
                    if (mode == "login") TextButton(onClick = onRecoveryMode, modifier = Modifier.align(Alignment.End)) { Text("نسيت كلمة المرور؟") }
                    Button(onClick = {
                        if (mode == "signup") onSignUp(email, password, username) else onSignIn(email, password)
                    }, enabled = !busy && email.isNotBlank() && password.length >= 6 && (mode != "signup" || password == password2), modifier = Modifier.fillMaxWidth().height(50.dp)) {
                        Text(if (busy) "جارٍ المعالجة…" else if (mode == "signup") "إنشاء الحساب" else "تسجيل الدخول")
                    }
                    OutlinedButton(onClick = { onModeChange(if (mode == "signup") "login" else "signup") }, enabled = !busy, modifier = Modifier.fillMaxWidth().height(48.dp)) { Text(if (mode == "signup") "لدي حساب بالفعل" else "إنشاء حساب جديد") }
                }
                notice?.let { Text(it, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp) }
            }
        } else if (recoveryMode) {
            Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }; Text("تغيير كلمة المرور", fontSize = 24.sp, fontWeight = FontWeight.Black) }
                OutlinedTextField(value = password, onValueChange = { password = it }, modifier = Modifier.fillMaxWidth(), label = { Text("كلمة المرور الجديدة") }, singleLine = true, visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
                OutlinedTextField(value = password2, onValueChange = { password2 = it }, modifier = Modifier.fillMaxWidth(), label = { Text("تأكيد كلمة المرور") }, singleLine = true, visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
                Button(onClick = { onUpdatePassword(password) }, enabled = !busy && password.length >= 6 && password == password2, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text(if (busy) "جارٍ الحفظ…" else "حفظ كلمة المرور") }
                notice?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
            }
        } else {
            LazyColumn(contentPadding = PaddingValues(bottom = 28.dp)) {
                item {
                    Box(Modifier.fillMaxWidth().height(220.dp)) {
                        if (!cover.isNullOrBlank()) AsyncImage(model = cover, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        else Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF171B25), Color(0xFF090B10)))))
                        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xFF080A0F)))))
                        IconButton(onClick = onBack, modifier = Modifier.align(Alignment.TopStart).padding(10.dp)) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
                    }
                    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.offset(y = (-58).dp).size(116.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant).clickable { uploadTarget = "avatar"; picker.launch("image/*") }) {
                            if (!avatar.isNullOrBlank()) AsyncImage(model = avatar, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            else Text("TV", modifier = Modifier.align(Alignment.Center), fontSize = 28.sp, fontWeight = FontWeight.Black)
                        }
                        Text(username.ifBlank { "مستخدم TV MOV" }, fontSize = 24.sp, fontWeight = FontWeight.Black, modifier = Modifier.offset(y = (-45).dp))
                        Text(SupabaseClient(context).email().orEmpty(), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.offset(y = (-40).dp))
                        Row(Modifier.fillMaxWidth().padding(top = 0.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { uploadTarget = "avatar"; picker.launch("image/*") }, modifier = Modifier.weight(1f)) { Text("الصورة") }
                            OutlinedButton(onClick = { uploadTarget = "cover"; picker.launch("image/*") }, modifier = Modifier.weight(1f)) { Text("الخلفية") }
                        }
                        if (uploading) Text("جارٍ رفع الصورة…", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                    }
                }
                item {
                    Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = MaterialTheme.shapes.extraLarge) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("تعديل الملف", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            OutlinedTextField(value = username, onValueChange = { username = it }, modifier = Modifier.fillMaxWidth(), label = { Text("اسم المستخدم") }, singleLine = true)
                            Button(onClick = { onUpdateProfile(username, avatar, cover) }, enabled = !busy && !uploading, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "جارٍ الحفظ…" else "حفظ التغييرات") }
                        }
                    }
                }
                item { AccountListSection("الأفلام التي شاهدتها", history.filter { it.isMovie }, onOpen) }
                item { AccountListSection("المسلسلات والأنمي التي شاهدتها", history.filter { !it.isMovie }, onOpen) }
                item { AccountListSection("المفضلة", favorites, onOpen) }
                item { AccountListSection("أريد مشاهدتها", watchLater, onOpen) }
                item {
                    OutlinedButton(onClick = onSignOut, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) { Text("تسجيل الخروج") }
                }
            }
        }
    }
}

@Composable
private fun AccountListSection(title: String, items: List<MediaItem>, onOpen: (MediaItem) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text(items.size.toString(), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))
        if (items.isEmpty()) {
            Text("لا توجد عناصر بعد", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        } else {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(items.take(10), key = { it.key }) { PosterCard(it, onOpen) }
            }
        }
    }
}
