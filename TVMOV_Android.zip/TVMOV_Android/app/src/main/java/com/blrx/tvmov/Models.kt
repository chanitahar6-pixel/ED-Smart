package com.blrx.tvmov

data class MediaItem(
    val id: Int,
    val mediaType: String,
    val title: String,
    val poster: String? = null,
    val year: String = "",
    val rating: Double? = null,
    val overview: String = "",
    val seasons: Int? = null,
    val sourceCategory: String? = null
) {
    val key: String get() = "$mediaType|$id"
    val isMovie: Boolean get() = mediaType == "movie"
    val isTv: Boolean get() = mediaType == "tv"
}

data class SeasonInfo(val season: Int, val episodes: List<Int>)

enum class HomeSection(val label: String, val path: String) {
    Movies("أفلام", "movies"),
    Series("مسلسلات", "tv"),
    New("جديدنا", "new"),
    Trending("الترند", "trending"),
    TopRated("الأعلى تقييمًا", "top-rated"),
    Anime("أنمي وكرتون", "anime")
}

data class CatalogState(
    val sections: Map<HomeSection, List<MediaItem>> = emptyMap(),
    val loading: Boolean = false,
    val error: String? = null
)
