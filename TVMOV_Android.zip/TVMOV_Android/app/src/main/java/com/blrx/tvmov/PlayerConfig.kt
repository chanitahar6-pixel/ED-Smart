package com.blrx.tvmov

/**
 * Embed sources retained from the original project.
 * Native Media3 playback is used only when a direct authorized media URL is resolved.
 */
object PlayerConfig {
    private val templates = listOf(
        "https://vidsrc.in/embed/{kind}/{id}{suffix}",
        "https://vidsrc.to/embed/{kind}/{id}{suffix}",
        "https://vidsrc.me/embed/{kind}/{id}{suffix}"
    )

    fun urls(item: MediaItem, season: Int? = null, episode: Int? = null): List<PlayerSource> {
        val kind = if (item.isTv) "tv" else "movie"
        val suffix = if (item.isTv && season != null && episode != null) "/$season/$episode" else ""
        return templates.mapIndexed { index, template ->
            PlayerSource(
                label = "مشغل ${index + 1}",
                url = template.replace("{kind}", kind).replace("{id}", item.id.toString()).replace("{suffix}", suffix)
            )
        }
    }
}
