package com.blrx.tvmov

/**
 * Embed sources - updated with currently active providers (2025-2026).
 * Native Media3 playback is used only when a direct authorized media URL is resolved.
 */
object PlayerConfig {

    fun urls(item: MediaItem, season: Int? = null, episode: Int? = null): List<PlayerSource> {
        val id = item.id.toString()
        val isMovie = item.isMovie
        val tvSuffix = if (!isMovie && season != null && episode != null) "/$season/$episode" else ""

        return buildList {
            if (isMovie) {
                add(PlayerSource("مشغل 1", "https://vidsrc.xyz/embed/movie/$id"))
                add(PlayerSource("مشغل 2", "https://embed.su/embed/movie/$id"))
                add(PlayerSource("مشغل 3", "https://2embed.cc/embed/movie/$id"))
                add(PlayerSource("مشغل 4", "https://player.autoembed.cc/embed/movie/$id"))
                add(PlayerSource("مشغل 5", "https://multiembed.mov/?video_id=$id&tmdb=1"))
            } else {
                val s = season ?: 1
                val e = episode ?: 1
                add(PlayerSource("مشغل 1", "https://vidsrc.xyz/embed/tv/$id/$s/$e"))
                add(PlayerSource("مشغل 2", "https://embed.su/embed/tv/$id/$s/$e"))
                add(PlayerSource("مشغل 3", "https://2embed.cc/embedtv/$id&s=$s&e=$e"))
                add(PlayerSource("مشغل 4", "https://player.autoembed.cc/embed/tv/$id/$s/$e"))
                add(PlayerSource("مشغل 5", "https://multiembed.mov/?video_id=$id&tmdb=1&s=$s&e=$e"))
            }
        }
    }
}
