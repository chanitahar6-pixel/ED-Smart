package com.blrx.tvmov

/**
 * Streaming source templates from the Telegram bot project.
 * Use only with sources/content you are authorized to access.
 */
object PlayerConfig {
    private val templates = listOf(
        "https://vidsrc.in/embed/{kind}/{id}{suffix}",
        "https://vidsrc.to/embed/{kind}/{id}{suffix}",
        "https://vidsrc.me/embed/{kind}/{id}{suffix}"
    )

    fun urls(item: MediaItem, season: Int? = null, episode: Int? = null): List<String> {
        val kind = if (item.isTv) "tv" else "movie"
        val suffix = if (item.isTv && season != null && episode != null) "/$season/$episode" else ""
        return templates.map { it.replace("{kind}", kind).replace("{id}", item.id.toString()).replace("{suffix}", suffix) }
    }
}
