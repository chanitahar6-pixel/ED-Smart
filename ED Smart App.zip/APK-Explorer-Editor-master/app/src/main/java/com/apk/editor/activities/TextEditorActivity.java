package com.apk.editor.activities;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.core.widget.ContentLoadingProgressBar;

import com.apk.axml.aXMLDecoder;
import com.apk.axml.aXMLEncoder;
import com.apk.editor.R;
import com.apk.editor.utils.APKExplorer;
import com.apk.editor.utils.AppData;
import com.apk.editor.utils.XMLEditor;
import com.apk.editor.utils.dialogs.FileActionDialog;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textview.MaterialTextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Objects;

import in.sunilpaulmathew.sCommon.CommonUtils.sCommonUtils;
import in.sunilpaulmathew.sCommon.CommonUtils.sExecutor;
import in.sunilpaulmathew.sCommon.FileUtils.sFileUtils;
import in.sunilpaulmathew.sCommon.ThemeUtils.sThemeUtils;

/*
 * Created by APK Explorer & Editor <apkeditor@protonmail.com> on March 25, 2021
 */
public class TextEditorActivity extends BaseActivity {

    private ContentLoadingProgressBar mProgressLayout;
    private MaterialAutoCompleteTextView mText;
    public static final String BACKUP_PATH_INTENT = "backup_path", PATH_INTENT = "path";
    private String mTextContents = null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_texteditor, R.id.layout_root);

        AppCompatImageButton mBack = findViewById(R.id.back);
        MaterialButton mSave = findViewById(R.id.save);
        mProgressLayout = findViewById(R.id.progress);
        MaterialTextView mTitle = findViewById(R.id.title);
        mText = findViewById(R.id.text);

        AppData.toggleKeyboard(1, mText, this);

        String backupPath = getIntent().getStringExtra(BACKUP_PATH_INTENT);
        String mPath = getIntent().getStringExtra(PATH_INTENT);

        mText.setTextColor(sThemeUtils.isDarkTheme(this) ? Color.WHITE : Color.BLACK);

        mTitle.setText(new File(Objects.requireNonNull(mPath)).getName());

        new sExecutor() {
            private boolean invalid = false;
            private String text = null;
            @Override
            public void onPreExecute() {
                mProgressLayout.setVisibility(View.VISIBLE);
            }

            @Override
            public void doInBackground() {
                if (APKExplorer.isBinaryXML(mPath)) {
                    try (FileInputStream fis = new FileInputStream(mPath)) {
                        text = new aXMLDecoder(fis).decodeAsString();
                    } catch (Exception e) {
                        invalid = true;
                    }
                } else {
                    text = sFileUtils.read(new File(mPath));
                }
            }

            @SuppressLint("StringFormatInvalid")
            @Override
            public void onPostExecute() {
                if (text != null) {
                    mText.setText(text);
                    mTextContents = text;
                }
                if (invalid) {
                    sCommonUtils.toast(getString(R.string.xml_decode_failed, new File(mPath).getName()), TextEditorActivity.this).show();
                }
                mProgressLayout.setVisibility(View.GONE);
            }
        }.execute();

        mSave.setVisibility(View.VISIBLE);

        mSave.setOnClickListener(v -> {
            if (mText == null || mText.getText() != null && mText.getText().toString().isEmpty()) return;
            new FileActionDialog(sCommonUtils.getDrawable(R.drawable.ic_file, this), getString(R.string.save_question), this) {
                @Override
                public void onPositiveAction() {
                    new sExecutor() {
                        private boolean invalid = false;
                        private final String text = mText.getText().toString().trim();
                        @Override
                        public void onPreExecute() {
                            mProgressLayout.setVisibility(View.VISIBLE);
                        }

                        @Override
                        public void doInBackground() {
                            if (APKExplorer.isBinaryXML(mPath)) {
                                if (XMLEditor.isXMLValid(text)) {
                                    try (FileOutputStream fos = new FileOutputStream(mPath)) {
                                        aXMLEncoder aXMLEncoder = new aXMLEncoder();
                                        byte[] bs = aXMLEncoder.encode(text);
                                        fos.write(bs);
                                    } catch (Exception ignored) {
                                    }
                                } else {
                                    invalid = true;
                                }
                            } else {
                                sFileUtils.create(text, new File(mPath));
                                if (mPath.contains("classes") && mPath.endsWith(".smali")) {
                                    try {
                                        File backupFile = new File(Objects.requireNonNull(backupPath));
                                        JSONObject jsonObject = new JSONObject(sFileUtils.read(backupFile));
                                        jsonObject.put("smali_edited", true);
                                        sFileUtils.create(jsonObject.toString(), backupFile);
                                    } catch (JSONException ignored) {
                                    }
                                }
                            }
                        }

                        @Override
                        public void onPostExecute() {
                            if (invalid) {
                                sCommonUtils.toast(getString(R.string.xml_corrupted), TextEditorActivity.this).show();
                            }
                            mProgressLayout.setVisibility(View.GONE);
                            finish();
                        }
                    }.execute();
                }
            };
        });

        mBack.setOnClickListener(v -> exit());

        getOnBackPressedDispatcher().addCallback(new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                exit();
            }
        });
    }

    private void exit() {
        if (mTextContents != null && mText.getText() != null && !mTextContents.equals(mText.getText().toString())) {
            new FileActionDialog(sCommonUtils.getDrawable(R.drawable.ic_file, this), getString(R.string.discard_message), this) {
                @Override
                public void onPositiveAction() {
                    finish();
                }
            };
            return;
        }
        finish();
    }

}