// This file is necessary because esbuild will fail to load the `any-observable`
// package (which is a transitive dependency of `apk-mitm`) otherwise. This file
// replaces that module and hard-codes the `Observable` implementation from
// `rxjs` as the one that is used by packages which import `any-observable`.

export { Observable as default } from "rxjs";
